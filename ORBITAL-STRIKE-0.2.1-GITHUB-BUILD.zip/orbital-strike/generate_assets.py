from PIL import Image, ImageDraw, ImageFilter
from pathlib import Path
import math, random, wave, struct, subprocess
import numpy as np

ROOT = Path(__file__).parent
ASSETS = ROOT / 'src/main/resources/assets/orbital_strike'
TEX = ASSETS / 'textures/item'
SOUNDS = ASSETS / 'sounds'
TEX.mkdir(parents=True, exist_ok=True)
SOUNDS.mkdir(parents=True, exist_ok=True)

# Small seamless-ish pixel materials used by the hand-built 3D item models.
materials = {
    'metal_dark': (30, 42, 55),
    'metal_light': (95, 117, 134),
    'rubber': (12, 17, 24),
    'energy_cyan': (25, 220, 255),
    'energy_blue': (50, 105, 255),
    'energy_violet': (174, 70, 255),
    'amber': (255, 169, 48),
    'alloy': (165, 180, 193),
}
for name, base in materials.items():
    im = Image.new('RGBA', (16, 16), (*base, 255))
    px = im.load()
    rng = random.Random(name)
    for y in range(16):
        for x in range(16):
            n = rng.randint(-13, 13)
            edge = 1.12 if y < 2 or x < 2 else 1.0
            px[x, y] = tuple(max(0, min(255, int(c*edge+n))) for c in base) + (255,)
    d = ImageDraw.Draw(im)
    d.line((0, 15, 15, 15), fill=(5, 8, 13, 255), width=1)
    if name.startswith('energy'):
        d.rectangle((2, 2, 13, 13), outline=tuple(min(255, c+45) for c in base)+(255,))
        d.point((7, 7), fill=(235, 255, 255, 255))
    im.save(TEX / f'{name}.png')

# 64x64 inventory portraits for documentation and future UI use.
def icon_base(glow):
    im = Image.new('RGBA', (64,64), (0,0,0,0))
    d = ImageDraw.Draw(im)
    d.ellipse((8,6,56,58), fill=(5,12,22,95), outline=glow+(180,), width=2)
    return im, d

# Designator: compact tactical handset, view screen and targeting antenna.
im, d = icon_base((42,220,255))
d.rounded_rectangle((18,12,45,49), radius=5, fill=(28,42,58,255), outline=(126,160,179,255), width=2)
d.rounded_rectangle((22,17,41,31), radius=2, fill=(5,25,39,255), outline=(30,220,255,255), width=2)
d.line((24,24,39,24), fill=(100,255,255,255), width=1)
d.line((31,18,31,30), fill=(100,255,255,255), width=1)
d.rectangle((24,35,39,39), fill=(65,87,101,255))
d.rounded_rectangle((24,42,39,54), radius=2, fill=(10,16,23,255), outline=(92,117,132,255), width=1)
d.line((43,15,53,7), fill=(35,220,255,255), width=3)
d.ellipse((50,4,56,10), fill=(135,255,255,255))
d.rectangle((13,25,18,34), fill=(255,168,48,255))
im.save(TEX / 'orbital_designator.png')

# Plasma rifle: body diagonally rising to the right, cyan capacitor.
im, d = icon_base((20,215,255))
d.polygon([(8,34),(16,28),(42,16),(52,20),(49,29),(23,42),(16,42)], fill=(36,52,68,255), outline=(150,180,196,255))
d.polygon([(14,39),(23,38),(21,56),(13,56)], fill=(16,23,31,255), outline=(100,130,148,255))
d.rectangle((34,17,52,22), fill=(65,83,100,255), outline=(172,192,205,255))
d.rectangle((48,18,59,21), fill=(15,24,34,255), outline=(65,220,255,255))
d.rectangle((26,28,38,34), fill=(18,35,48,255), outline=(24,210,255,255), width=2)
d.line((28,31,36,31), fill=(235,255,255,255), width=2)
d.line((18,31,29,24), fill=(255,174,54,255), width=2)
im.save(TEX / 'plasma_rifle.png')

# Quantum sniper: precision barrel, long stock and violet optic.
im, d = icon_base((181,82,255))
d.polygon([(5,32),(14,26),(49,18),(59,22),(56,29),(18,39),(10,40)], fill=(34,45,62,255), outline=(154,171,191,255))
d.rectangle((35,18,60,23), fill=(62,76,94,255), outline=(183,198,210,255))
d.rectangle((52,17,62,21), fill=(12,19,29,255), outline=(165,80,255,255))
d.rounded_rectangle((26,14,40,23), radius=2, fill=(16,24,38,255), outline=(196,94,255,255), width=2)
d.rectangle((29,16,37,20), fill=(112,49,190,255))
d.polygon([(9,35),(20,36),(22,51),(14,55),(8,48)], fill=(13,19,28,255), outline=(119,137,156,255))
d.rectangle((28,29,40,34), fill=(82,103,123,255), outline=(173,95,255,255), width=2)
im.save(TEX / 'quantum_sniper.png')

# Project insignia.
logo = Image.new('RGBA', (128,128), (7,12,22,255))
d = ImageDraw.Draw(logo)
d.ellipse((16,16,112,112), outline=(20,207,255,255), width=4)
d.ellipse((28,28,100,100), outline=(72,105,255,255), width=2)
d.polygon([(64,12),(75,50),(116,64),(75,77),(64,116),(52,77),(12,64),(52,50)], fill=(18,140,210,255), outline=(140,245,255,255))
d.ellipse((54,54,74,74), fill=(235,250,255,255), outline=(0,40,70,255), width=2)
logo.save(ASSETS / 'icon.png')

# Item-definition JSON for the 26.x item model system and hand-built low-poly voxel models.
def faces(tex):
    return {face: {'uv':[0,0,16,16], 'texture': '#'+tex} for face in ['north','south','east','west','up','down']}

def cube(frm, to, tex, name=None):
    # The name argument documents the design in source only; vanilla model JSON has no element-name field.
    return {'from':frm, 'to':to, 'faces':faces(tex)}

def model(name, cubes, display):
    textures = {
        'dark':'orbital_strike:item/metal_dark',
        'metal':'orbital_strike:item/metal_light',
        'rubber':'orbital_strike:item/rubber',
        'cyan':'orbital_strike:item/energy_cyan',
        'blue':'orbital_strike:item/energy_blue',
        'violet':'orbital_strike:item/energy_violet',
        'amber':'orbital_strike:item/amber',
        'alloy':'orbital_strike:item/alloy'
    }
    # Model uses a small palette; the display transform is tuned for an angled first-person weapon silhouette.
    data = {'credit':'ORBITAL STRIKE Studio', 'gui_light':'front', 'textures':textures, 'elements':cubes,
            'display':display}
    data['textures']['particle'] = f'orbital_strike:item/{name}'
    (ASSETS/'models/item'/f'{name}.json').write_text(__import__('json').dumps(data, indent=2))
    item_def = {'model': {'type':'minecraft:model', 'model':f'orbital_strike:item/{name}'}}
    (ASSETS/'items'/f'{name}.json').write_text(__import__('json').dumps(item_def, indent=2))

common_display = {
  'gui': {'rotation':[25,225,0], 'translation':[0,0,0], 'scale':[0.95,0.95,0.95]},
  'ground': {'rotation':[0,0,0], 'translation':[0,2,0], 'scale':[0.55,0.55,0.55]},
  'fixed': {'rotation':[0,180,0], 'translation':[0,0,0], 'scale':[0.8,0.8,0.8]},
  'thirdperson_righthand': {'rotation':[0,-90,55], 'translation':[0,3.0,1.1], 'scale':[0.85,0.85,0.85]},
  'thirdperson_lefthand': {'rotation':[0,90,-55], 'translation':[0,3.0,1.1], 'scale':[0.85,0.85,0.85]},
  'firstperson_righthand': {'rotation':[0,-90,25], 'translation':[1.0,3.2,1.2], 'scale':[0.72,0.72,0.72]},
  'firstperson_lefthand': {'rotation':[0,90,-25], 'translation':[1.0,3.2,1.2], 'scale':[0.72,0.72,0.72]}
}

model('orbital_designator', [
    cube([3,4,4],[13,13,12],'dark','armored shell'),
    cube([4,9,3],[12,12,4],'metal','display bezel'),
    cube([5,9,2.8],[11,11,3.2],'cyan','holographic targeting glass'),
    cube([5,1,6],[11,5,10],'rubber','grip'),
    cube([6,6,12],[10,10,15],'metal','sensor head'),
    cube([7,7,15],[9,9,16],'cyan','laser emitter'),
    cube([12,12,5],[14,15,6],'amber','status LED'),
], common_display)

model('plasma_rifle', [
    cube([2,6,4],[13,11,12],'dark','receiver'),
    cube([9,8,5],[16,10,11],'metal','plasma barrel'),
    cube([14,8,6],[16,10,10],'cyan','muzzle coil'),
    cube([5,2,6],[9,7,10],'rubber','pistol grip'),
    cube([4,10,5],[11,13,11],'metal','upper rail'),
    cube([6,11,6],[10,12,10],'cyan','capacitor cell'),
    cube([1,7,5],[4,10,11],'alloy','rear stock'),
    cube([10,5,3],[12,7,5],'amber','charge indicator'),
], common_display)

model('quantum_sniper', [
    cube([1,6,5],[13,10,11],'dark','rifle receiver'),
    cube([7,8,6],[16,10,10],'metal','long-range barrel'),
    cube([14,8,7],[16,10,9],'violet','quantum muzzle lens'),
    cube([5,10,5],[10,14,11],'metal','optic housing'),
    cube([6,11,4],[9,13,5],'violet','quantum optic'),
    cube([3,2,6],[7,7,10],'rubber','precision grip'),
    cube([0,6,6],[3,10,10],'alloy','shoulder stock'),
    cube([10,4,6],[13,7,10],'blue','phase cell'),
], common_display)

# Procedural one-shot sci-fi sounds, generated in mono and encoded as OGG Vorbis.
SR = 48000
rng = np.random.default_rng(263)
def write_ogg(name, samples):
    samples = np.asarray(samples, dtype=np.float32)
    peak = np.max(np.abs(samples)) or 1.0
    samples = samples / max(1.0, peak) * 0.88
    wav_path = SOUNDS / f'{name}.wav'
    ogg_path = SOUNDS / f'{name}.ogg'
    pcm = np.int16(np.clip(samples, -1, 1) * 32767)
    with wave.open(str(wav_path), 'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(wav_path),'-c:a','libvorbis','-q:a','5',str(ogg_path)], check=True)
    wav_path.unlink()

# Target lock: scanning sine chirps with short digital pips.
t = np.arange(int(SR*1.65))/SR
sweep = np.sin(2*np.pi*(420*t - 150*t*t))*np.exp(-2.1*t)
pips = np.zeros_like(t)
for st in [0.08,0.36,0.64,0.92,1.20,1.42]:
    m = (t>=st)&(t<st+0.055)
    tt = t[m]-st
    pips[m] += 0.28*np.sin(2*np.pi*(1150-400*tt)*tt)*np.exp(-45*tt)
write_ogg('target_lock', 0.28*sweep + pips)

# Plasma discharge: sharp transient plus a short rising electrical buzz.
t = np.arange(int(SR*0.32))/SR
noise = rng.normal(0,1,len(t))*np.exp(-20*t)
plasma = 0.42*noise + 0.38*np.sin(2*np.pi*(180+900*t)*t)*np.exp(-9*t) + 0.18*np.sin(2*np.pi*65*t)*np.exp(-14*t)
write_ogg('plasma_fire', plasma)

# Quantum shot: compressed charge whine into a hard, falling phase snap.
t = np.arange(int(SR*0.78))/SR
charge = np.sin(2*np.pi*(250+1900*t)*t)*np.clip(t/0.25,0,1)*np.exp(-3*t)
snap = np.sin(2*np.pi*(1400-1000*t)*t)*np.exp(-30*np.maximum(t-0.25,0))
rumble = rng.normal(0,1,len(t))*np.exp(-10*np.maximum(t-0.23,0))
write_ogg('quantum_fire', 0.38*charge + 0.34*snap + 0.12*rumble)

# Orbital impact: low-frequency cinematic thump, noisy debris tail and bright metallic crack.
t = np.arange(int(SR*3.8))/SR
impact = 0.60*np.sin(2*np.pi*(38-8*t)*t)*np.exp(-1.7*t)
impact += 0.42*rng.normal(0,1,len(t))*np.exp(-2.8*t)
impact += 0.22*np.sin(2*np.pi*170*t)*np.exp(-8*t)
impact += 0.10*np.sin(2*np.pi*1300*t)*np.exp(-18*t)
impact[:120] += np.linspace(0.0,0.75,120)
write_ogg('orbital_impact', impact)
