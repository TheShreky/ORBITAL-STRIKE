# Architecture

## Runtime ownership

- Item `use` actions enter on the logical server. The client does not apply damage or terrain changes.
- `WeaponTargeting` clips rays against blocks, checks entity bounding boxes, and sorts targets by distance. Piercing weapons stop at the block-occluded segment and cap the number of targets.
- `OrbitalStrikeScheduler` stores dimension, coordinates, owner UUID, countdown, effect radius, damage and terrain flags. It never retains live player/entity references.
- `SingularityScheduler` stores a dimension, centre point, owner UUID and remaining ticks. Each server tick attracts eligible entities and applies periodic damage; at expiry it collapses and removes the scheduled field.
- `OrbitalConfig` clamps settings and merges newly introduced defaults into existing config files.
- `AdvancedWeaponItem` shares a server-side implementation among individually registered weapon kinds. Their range, cooldown, damage, radius and attack behaviour differ by kind.
- Assets remain data-driven: item definition JSON points at custom cube models, which reference a controlled palette of texture atlases; sounds are mono Vorbis OGG resources.

## Damage and terrain

All damage is applied by server code. Player targets are checked against the attacker's PvP permission. Owner entities are excluded from their own radial and singularity damage. Terrain destruction is a separate, bounded pass with a hard limit on checked positions; negative-hardness blocks and blocks above the hardness safety threshold are preserved. Nuclear terrain damage defaults off. Standard orbital terrain damage is separately configurable.

## Performance choices

- Hitscan does not create persistent projectile entities.
- Particle counts use fixed segment and ring budgets.
- The singularity performs attraction and particles every two ticks, not for every world entity globally; entities are queried only inside its local AABB.
- Pending orbital strikes and singularities are removed on completion or if their dimension becomes unavailable.
- No per-entity tick handler is installed.

## Multiplayer model

Target selection, cooldowns, damage, strike countdown, singularity forces, terrain changes, and sound broadcasting are server-owned. Clients receive standard synced particles, sounds and item state. PvP checks are applied to direct and radial weapon attacks. This model still needs real dedicated-server testing and compatibility testing with protection mods before being called production-ready.
