# Development phase status

Release: **Alpha 0.2.0** — source/assets package; not yet compiled in this environment.

| Phase | Status | Delivered |
|---|---|---|
| 1 — Architecture and environment | Source created; external build not run | Fabric 26.3 project, Java 25 configuration, server config, architecture notes |
| 2 — Weapon systems and models | Expanded functional source implementation | Full requested 12-weapon roster plus Orbital Designator, 13 weapon/tool entries, individual low-poly item models and textures |
| 3 — Animations and VFX | Partial | Server particles, beam trails, energy slash, target rings, rocket impacts, black-hole field, custom OGG sound assets; no rigged first-person animation controller |
| 4 — Orbital Strike | Functional source implementation, uncompiled here | Delayed standard strike, operator-gated nuclear strike, delayed drone-missile strike, configurable damage and terrain settings |
| 5 — Technology, machines, drones, enemies | Partial/deferred | Crafting components and weapon progression exist; custom flying drone entity, turrets, generators, robot enemies and bosses are not implemented |
| 6 — Custom UI/HUD | Partial | Weapon/action feedback via action-bar overlays and status messages; full-screen holographic menus and animated radar HUD are not implemented |
| 7 — Multiplayer and optimization | Server-authoritative source design, untested | Server-side ray targeting, damage, cooldowns, scheduled impacts, singularity tick processing, PvP checks, bounded particle loops; dedicated-server test deferred |
| 8 — Testing and packaging | Asset validation only | Source ZIP and guide; Java compile, remap, client launch, dedicated-server launch and final JAR still require external Java 25 + Gradle dependency access |

## Explicitly not shipped as working features

No custom animated entity rigs, autonomous flying drone entity, hostile robot/soldier AI, mechanical boss, placeable turret, shield projector block, power generator block, holographic GUI screen, reload/inspection animation controller, volumetric lighting or machine AI/Redstone EMP shutdown is included. These systems need additional registries, synced entity/block state, client renderers and in-game integration tests. The current drone missile uses a delayed, server-scheduled strike effect instead of a rendered autonomous drone. The EMP is currently an area pulse, not an AI/Redstone disabling mechanic.

## Build/test boundary

`validate_project.py` checks resource JSON, item model references, recipe IDs, OGG file headers and archive contents. It does not replace Gradle compilation or Minecraft runtime tests. The current container has Java 21, no Gradle executable, and cannot resolve external download hosts; consequently no JAR is claimed as compiled or tested.
