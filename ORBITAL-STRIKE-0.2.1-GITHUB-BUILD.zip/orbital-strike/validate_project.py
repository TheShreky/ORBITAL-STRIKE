"""Offline resource validation for ORBITAL STRIKE. Does not compile Java or launch Minecraft."""
from pathlib import Path
import json, re, struct, sys
ROOT=Path(__file__).parent
RES=ROOT/'src/main/resources'
errors=[]; notes=[]
json_files=list(RES.rglob('*.json'))
for path in json_files:
    try: json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc: errors.append(f'Invalid JSON {path.relative_to(ROOT)}: {exc}')

# Check every registered custom item has a 26.x item definition and a model + texture particle sprite.
java=(ROOT/'src/main/java/com/orbitalstrike/content/ModItems.java').read_text()
registered=set(re.findall(r'(?:register|advanced|material)\("([a-z0-9_]+)"',java))
for name in sorted(registered):
    idef=RES/f'assets/orbital_strike/items/{name}.json'
    model=RES/f'assets/orbital_strike/models/item/{name}.json'
    tex=RES/f'assets/orbital_strike/textures/item/{name}.png'
    if not idef.exists(): errors.append(f'Missing item definition: {idef.relative_to(ROOT)}')
    if not model.exists(): errors.append(f'Missing item model: {model.relative_to(ROOT)}')
    if not tex.exists(): errors.append(f'Missing particle/item texture: {tex.relative_to(ROOT)}')

# Resolve each texture referenced by item-model JSON.
for path in (RES/'assets/orbital_strike/models/item').glob('*.json'):
    try: model=json.loads(path.read_text())
    except Exception: continue
    for key,value in model.get('textures',{}).items():
        if not isinstance(value,str) or ':' not in value: continue
        ns,rel=value.split(':',1)
        texture=RES/f'assets/{ns}/textures/{rel}.png'
        if not texture.exists(): errors.append(f'Missing model texture {value} referenced by {path.relative_to(ROOT)}')

# Resolve all mod recipe input and output item identifiers.
mod_id='orbital_strike:'
for path in (RES/'data/orbital_strike/recipe').glob('*.json'):
    try: recipe=json.loads(path.read_text())
    except Exception: continue
    result=recipe.get('result',{}).get('id','')
    if result.startswith(mod_id) and result.split(':',1)[1] not in registered:
        errors.append(f'Recipe {path.name} creates unknown item {result}')
    for item in re.findall(r'orbital_strike:[a-z0-9_]+',json.dumps(recipe)):
        if item.split(':',1)[1] not in registered:
            errors.append(f'Recipe {path.name} references unknown item {item}')

# Validate language keys, sounds and OGG/Vorbis container markers.
lang=json.loads((RES/'assets/orbital_strike/lang/en_us.json').read_text())
for name in re.findall(r'(?:register|advanced|material)\("([a-z0-9_]+)"',java):
    key=f'item.orbital_strike.{name}'
    if key not in lang: errors.append(f'Missing translation key: {key}')
sound_defs=json.loads((RES/'assets/orbital_strike/sounds.json').read_text())
for name in sound_defs:
    ogg=RES/f'assets/orbital_strike/sounds/{name}.ogg'
    if not ogg.exists(): errors.append(f'Missing OGG for sound event: {name}')
    else:
        header=ogg.read_bytes()[:4]
        if header != b'OggS': errors.append(f'Invalid OGG container: {ogg.relative_to(ROOT)}')

# Validate Java sources are non-empty and key implementation points are present.
source_files=list((ROOT/'src/main/java').rglob('*.java'))
for p in source_files:
    if p.stat().st_size < 100: errors.append(f'Suspiciously small Java source: {p.relative_to(ROOT)}')
checks={
 'Advanced 12-weapon behaviours':'enum Kind' in (ROOT/'src/main/java/com/orbitalstrike/item/AdvancedWeaponItem.java').read_text(),
 'Server-side singularity scheduler':'class SingularityScheduler' in (ROOT/'src/main/java/com/orbitalstrike/combat/SingularityScheduler.java').read_text(),
 'Orbital strike scheduler':'class OrbitalStrikeScheduler' in (ROOT/'src/main/java/com/orbitalstrike/combat/OrbitalStrikeScheduler.java').read_text(),
}
for label,ok in checks.items():
    if not ok: errors.append(f'Missing source feature: {label}')

print(f'JSON files checked: {len(json_files)}')
print(f'Registered custom items discovered: {len(registered)}')
print(f'Item models checked: {len(list((RES/"assets/orbital_strike/models/item").glob("*.json")))}')
print(f'Audio events checked: {len(sound_defs)}')
print(f'Java source files: {len(source_files)}')
if errors:
    print('\nVALIDATION FAILED:')
    for err in errors: print(' -',err)
    sys.exit(1)
print('RESOURCE VALIDATION PASSED (this is not a Gradle/Java compile or Minecraft runtime test).')
