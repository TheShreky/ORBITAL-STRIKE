@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ORBITAL STRIKE - Build

echo ================================================
echo          ORBITAL STRIKE - ONE CLICK BUILD
echo ================================================
echo.

where java >nul 2>nul
if errorlevel 1 goto nojava
for /f "tokens=3" %%V in ('java -version 2^>^&1 ^| findstr /i "version"') do set JAVA_VERSION=%%~V
if not defined JAVA_VERSION goto badjava
 echo Detected Java %JAVA_VERSION%
echo %JAVA_VERSION% | findstr /b "25" >nul
if errorlevel 1 goto badjava

set "GRADLE_HOME=%CD%\.tools\gradle-9.8.2"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto build
if not exist ".tools" mkdir ".tools"
echo.
echo Downloading Gradle 9.8.2 automatically. This may take a few minutes...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-9.8.2-bin.zip' -OutFile '.tools\gradle.zip'; Expand-Archive -LiteralPath '.tools\gradle.zip' -DestinationPath '.tools' -Force; Remove-Item '.tools\gradle.zip' -Force"
if errorlevel 1 goto downloadfailed

:build
echo.
echo Building ORBITAL STRIKE...
call "%GRADLE_HOME%\bin\gradle.bat" --no-daemon build
if errorlevel 1 goto buildfailed
echo.
echo ================================================
echo BUILD SUCCESSFUL
echo Your mod JAR is in: build\libs\
echo Copy the remapped JAR into your OneClient mods folder.
echo ================================================
explorer "%CD%\build\libs"
pause
exit /b 0

:nojava
echo Java 25 JDK was not found.
echo Install a Java 25 JDK first, then double-click this file again.
start "" "https://adoptium.net/temurin/releases/?version=25"
pause
exit /b 1

:badjava
echo This project requires Java 25. The detected Java version is not 25.
echo Install a Java 25 JDK, then double-click this file again.
start "" "https://adoptium.net/temurin/releases/?version=25"
pause
exit /b 1

:downloadfailed
echo Gradle could not be downloaded. Check your internet connection and try again.
pause
exit /b 1

:buildfailed
echo Build failed. The project needs a source/API fix; no usable JAR was produced.
pause
exit /b 1
