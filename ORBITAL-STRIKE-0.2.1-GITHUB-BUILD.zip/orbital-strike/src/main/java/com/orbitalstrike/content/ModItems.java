package com.orbitalstrike.content;

import com.orbitalstrike.OrbitalStrikeMod;
import com.orbitalstrike.item.AdvancedWeaponItem;
import com.orbitalstrike.item.OrbitalDesignatorItem;
import com.orbitalstrike.item.PlasmaRifleItem;
import com.orbitalstrike.item.QuantumSniperItem;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

import java.util.function.Function;

public final class ModItems {
    public static final Item ORBITAL_DESIGNATOR = register("orbital_designator", OrbitalDesignatorItem::new,
            new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
    public static final Item PLASMA_RIFLE = register("plasma_rifle", PlasmaRifleItem::new,
            new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
    public static final Item QUANTUM_SNIPER = register("quantum_sniper", QuantumSniperItem::new,
            new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    public static final Item ORBITAL_LASER_CANNON = advanced("orbital_laser_cannon", AdvancedWeaponItem.Kind.ORBITAL_LASER, Rarity.EPIC);
    public static final Item HEAVY_RAILGUN = advanced("heavy_railgun", AdvancedWeaponItem.Kind.HEAVY_RAILGUN, Rarity.EPIC);
    public static final Item ENERGY_SWORD = advanced("energy_sword", AdvancedWeaponItem.Kind.ENERGY_SWORD, Rarity.RARE);
    public static final Item NUCLEAR_BOMBARDMENT = advanced("nuclear_bombardment", AdvancedWeaponItem.Kind.NUCLEAR_BOMBARDMENT, Rarity.EPIC);
    public static final Item GRAVITY_MANIPULATOR = advanced("gravity_manipulator", AdvancedWeaponItem.Kind.GRAVITY_MANIPULATOR, Rarity.EPIC);
    public static final Item ROCKET_LAUNCHER = advanced("rocket_launcher", AdvancedWeaponItem.Kind.ROCKET_LAUNCHER, Rarity.RARE);
    public static final Item DRONE_MISSILE_SYSTEM = advanced("drone_missile_system", AdvancedWeaponItem.Kind.DRONE_MISSILE, Rarity.EPIC);
    public static final Item BLACK_HOLE_LAUNCHER = advanced("black_hole_launcher", AdvancedWeaponItem.Kind.BLACK_HOLE, Rarity.EPIC);
    public static final Item EMP_CANNON = advanced("emp_cannon", AdvancedWeaponItem.Kind.EMP_CANNON, Rarity.RARE);
    public static final Item PARTICLE_ACCELERATOR = advanced("particle_accelerator", AdvancedWeaponItem.Kind.PARTICLE_ACCELERATOR, Rarity.EPIC);

    public static final Item NEUTRON_ALLOY = material("neutron_alloy", Rarity.UNCOMMON);
    public static final Item QUANTUM_CORE = material("quantum_core", Rarity.RARE);
    public static final Item PLASMA_CELL = material("plasma_cell", Rarity.UNCOMMON);
    public static final Item ORBITAL_CIRCUIT = material("orbital_circuit", Rarity.RARE);

    private ModItems() {}

    private static Item advanced(String name, AdvancedWeaponItem.Kind kind, Rarity rarity) {
        return register(name, properties -> new AdvancedWeaponItem(kind, properties),
                new Item.Properties().stacksTo(1).rarity(rarity));
    }

    private static Item material(String name, Rarity rarity) {
        return register(name, Item::new, new Item.Properties().rarity(rarity));
    }

    private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties properties) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, OrbitalStrikeMod.id(name));
        Item item = factory.apply(properties.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void initialize() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(entries -> {
            entries.accept(ORBITAL_DESIGNATOR);
            entries.accept(PLASMA_RIFLE);
            entries.accept(QUANTUM_SNIPER);
            entries.accept(ORBITAL_LASER_CANNON);
            entries.accept(HEAVY_RAILGUN);
            entries.accept(ENERGY_SWORD);
            entries.accept(NUCLEAR_BOMBARDMENT);
            entries.accept(GRAVITY_MANIPULATOR);
            entries.accept(ROCKET_LAUNCHER);
            entries.accept(DRONE_MISSILE_SYSTEM);
            entries.accept(BLACK_HOLE_LAUNCHER);
            entries.accept(EMP_CANNON);
            entries.accept(PARTICLE_ACCELERATOR);
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(NEUTRON_ALLOY);
            entries.accept(QUANTUM_CORE);
            entries.accept(PLASMA_CELL);
            entries.accept(ORBITAL_CIRCUIT);
        });
        OrbitalStrikeMod.LOGGER.info("Registered 13 weapons/tools and 4 research components.");
    }
}
