package com.orbitalstrike;

import com.orbitalstrike.combat.OrbitalStrikeScheduler;
import com.orbitalstrike.combat.SingularityScheduler;
import com.orbitalstrike.config.OrbitalConfig;
import com.orbitalstrike.content.ModItems;
import com.orbitalstrike.sound.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class OrbitalStrikeMod implements ModInitializer {
    public static final String MOD_ID = "orbital_strike";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        OrbitalConfig.load();
        ModSounds.initialize();
        ModItems.initialize();
        ServerTickEvents.END_SERVER_TICK.register(OrbitalStrikeScheduler::tick);
        ServerTickEvents.END_SERVER_TICK.register(SingularityScheduler::tick);
        LOGGER.info("ORBITAL STRIKE {} online — server-authoritative weapon systems initialized.", "0.2.0-alpha");
    }
}
