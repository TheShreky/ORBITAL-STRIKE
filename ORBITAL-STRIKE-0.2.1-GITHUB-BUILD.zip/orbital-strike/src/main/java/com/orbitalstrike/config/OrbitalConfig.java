package com.orbitalstrike.config;

import com.orbitalstrike.OrbitalStrikeMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Small dependency-free server config. Values are clamped before gameplay uses them. */
public final class OrbitalConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("orbital-strike.properties");

    public static int strikeDelayTicks = 50;
    public static int strikeCooldownTicks = 240;
    public static double strikeRadius = 9.0;
    public static float strikeDamage = 32.0F;
    public static boolean terrainDamage = true;
    public static boolean requireOperator = true;
    public static double plasmaRange = 52.0;
    public static float plasmaDamage = 8.0F;
    public static int plasmaCooldownTicks = 10;
    public static double sniperRange = 128.0;
    public static float sniperDamage = 27.0F;
    public static int sniperCooldownTicks = 52;
    public static double specialDamageMultiplier = 1.0;
    public static double specialCooldownMultiplier = 1.0;
    public static boolean nuclearTerrainDamage = false;

    private OrbitalConfig() {}

    public static void load() {
        Properties values = new Properties();
        if (Files.exists(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE)) {
                values.load(reader);
            } catch (IOException exception) {
                OrbitalStrikeMod.LOGGER.error("Could not read {}. Defaults will be used.", FILE, exception);
            }
        }

        strikeDelayTicks = integer(values, "orbital.delay_ticks", strikeDelayTicks, 20, 200);
        strikeCooldownTicks = integer(values, "orbital.cooldown_ticks", strikeCooldownTicks, 40, 2400);
        strikeRadius = decimal(values, "orbital.radius", strikeRadius, 3.0, 24.0);
        strikeDamage = (float) decimal(values, "orbital.damage", strikeDamage, 1.0, 200.0);
        terrainDamage = bool(values, "orbital.terrain_damage", terrainDamage);
        requireOperator = bool(values, "orbital.require_operator", requireOperator);
        plasmaRange = decimal(values, "plasma.range", plasmaRange, 8.0, 128.0);
        plasmaDamage = (float) decimal(values, "plasma.damage", plasmaDamage, 1.0, 40.0);
        plasmaCooldownTicks = integer(values, "plasma.cooldown_ticks", plasmaCooldownTicks, 1, 100);
        sniperRange = decimal(values, "sniper.range", sniperRange, 24.0, 256.0);
        sniperDamage = (float) decimal(values, "sniper.damage", sniperDamage, 1.0, 100.0);
        sniperCooldownTicks = integer(values, "sniper.cooldown_ticks", sniperCooldownTicks, 5, 200);
        specialDamageMultiplier = decimal(values, "special.damage_multiplier", specialDamageMultiplier, 0.25, 4.0);
        specialCooldownMultiplier = decimal(values, "special.cooldown_multiplier", specialCooldownMultiplier, 0.25, 4.0);
        nuclearTerrainDamage = bool(values, "nuclear.terrain_damage", nuclearTerrainDamage);

        saveDefaultsIfMissing();
    }

    private static int integer(Properties p, String key, int fallback, int min, int max) {
        try { return Math.clamp(Integer.parseInt(p.getProperty(key, Integer.toString(fallback)).trim()), min, max); }
        catch (RuntimeException ignored) { return fallback; }
    }

    private static double decimal(Properties p, String key, double fallback, double min, double max) {
        try { return Math.clamp(Double.parseDouble(p.getProperty(key, Double.toString(fallback)).trim()), min, max); }
        catch (RuntimeException ignored) { return fallback; }
    }

    private static boolean bool(Properties p, String key, boolean fallback) {
        String raw = p.getProperty(key);
        return raw == null ? fallback : Boolean.parseBoolean(raw.trim());
    }

    private static void saveDefaultsIfMissing() {
        Properties defaults = new Properties();
        defaults.setProperty("orbital.delay_ticks", Integer.toString(strikeDelayTicks));
        defaults.setProperty("orbital.cooldown_ticks", Integer.toString(strikeCooldownTicks));
        defaults.setProperty("orbital.radius", Double.toString(strikeRadius));
        defaults.setProperty("orbital.damage", Float.toString(strikeDamage));
        defaults.setProperty("orbital.terrain_damage", Boolean.toString(terrainDamage));
        defaults.setProperty("orbital.require_operator", Boolean.toString(requireOperator));
        defaults.setProperty("plasma.range", Double.toString(plasmaRange));
        defaults.setProperty("plasma.damage", Float.toString(plasmaDamage));
        defaults.setProperty("plasma.cooldown_ticks", Integer.toString(plasmaCooldownTicks));
        defaults.setProperty("sniper.range", Double.toString(sniperRange));
        defaults.setProperty("sniper.damage", Float.toString(sniperDamage));
        defaults.setProperty("sniper.cooldown_ticks", Integer.toString(sniperCooldownTicks));
        defaults.setProperty("special.damage_multiplier", Double.toString(specialDamageMultiplier));
        defaults.setProperty("special.cooldown_multiplier", Double.toString(specialCooldownMultiplier));
        defaults.setProperty("nuclear.terrain_damage", Boolean.toString(nuclearTerrainDamage));

        Properties existing = new Properties();
        if (Files.exists(FILE)) {
            try (Reader reader = Files.newBufferedReader(FILE)) {
                existing.load(reader);
            } catch (IOException exception) {
                OrbitalStrikeMod.LOGGER.error("Could not merge defaults into {}.", FILE, exception);
                return;
            }
        }
        boolean changed = false;
        for (String key : defaults.stringPropertyNames()) {
            if (!existing.containsKey(key)) {
                existing.setProperty(key, defaults.getProperty(key));
                changed = true;
            }
        }
        if (!changed && Files.exists(FILE)) return;
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                existing.store(writer, "ORBITAL STRIKE server gameplay settings");
            }
        } catch (IOException exception) {
            OrbitalStrikeMod.LOGGER.error("Could not create/update {}.", FILE, exception);
        }
    }
}
