package com.orbitalstrike.sound;

import com.orbitalstrike.OrbitalStrikeMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public final class ModSounds {
    public static final SoundEvent TARGET_LOCK = register("target_lock");
    public static final SoundEvent PLASMA_FIRE = register("plasma_fire");
    public static final SoundEvent QUANTUM_FIRE = register("quantum_fire");
    public static final SoundEvent ORBITAL_IMPACT = register("orbital_impact");
    public static final SoundEvent ORBITAL_LASER = register("orbital_laser");
    public static final SoundEvent RAILGUN_FIRE = register("railgun_fire");
    public static final SoundEvent BLADE_SWING = register("blade_swing");
    public static final SoundEvent MISSILE_IMPACT = register("missile_impact");
    public static final SoundEvent SINGULARITY = register("singularity");
    public static final SoundEvent EMP_BLAST = register("emp_blast");

    private ModSounds() {}
    private static SoundEvent register(String name) {
        Identifier id = OrbitalStrikeMod.id(name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }
    public static void initialize() {
        OrbitalStrikeMod.LOGGER.info("Registered 10 custom sound events.");
    }
}
