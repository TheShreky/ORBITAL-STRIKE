package com.orbitalstrike.combat;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Server-side, block-occluded ray selection shared by precision and piercing weapons. */
public final class WeaponTargeting {
    public record Target(LivingEntity entity, Vec3 hitPoint, double distance) {}

    private WeaponTargeting() {}

    public static List<Target> acquireAll(Level level, Player player, double maxRange) {
        Vec3 start = player.getEyePosition();
        Vec3 direction = player.getViewVector(1.0F).normalize();
        Vec3 end = start.add(direction.scale(maxRange));
        HitResult blockHit = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        double visibleDistance = blockHit.getType() == HitResult.Type.BLOCK
                ? blockHit.getLocation().distanceTo(start) : maxRange;

        AABB search = player.getBoundingBox().expandTowards(direction.scale(visibleDistance)).inflate(2.5);
        List<Target> targets = new ArrayList<>();
        for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class, search,
                entity -> entity.isAlive() && !entity.isSpectator() && entity != player)) {
            Vec3 center = candidate.getBoundingBox().getCenter();
            double alongRay = center.subtract(start).dot(direction);
            if (alongRay <= 0.0 || alongRay > visibleDistance) continue;
            Vec3 closestPoint = start.add(direction.scale(alongRay));
            if (!candidate.getBoundingBox().inflate(0.18).contains(closestPoint)) continue;
            targets.add(new Target(candidate, closestPoint, alongRay));
        }
        targets.sort(Comparator.comparingDouble(Target::distance));
        return targets;
    }

    public static Target acquire(Level level, Player player, double maxRange) {
        List<Target> targets = acquireAll(level, player, maxRange);
        return targets.isEmpty() ? null : targets.getFirst();
    }

    public static Vec3 blockAim(Player player, double range) {
        return player.pick(range, 1.0F, false).getLocation();
    }
}
