package com.orbitalstrike.combat;

import com.orbitalstrike.config.OrbitalConfig;
import com.orbitalstrike.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** Server-only strike queue. Each request stores immutable world data, never entity references. */
public final class OrbitalStrikeScheduler {
    private static final List<PendingStrike> PENDING = new ArrayList<>();

    private OrbitalStrikeScheduler() {}

    public static void schedule(ServerLevel level, ServerPlayer owner, Vec3 target) {
        schedule(level, owner, target, OrbitalConfig.strikeDelayTicks,
                OrbitalConfig.strikeRadius, OrbitalConfig.strikeDamage, OrbitalConfig.terrainDamage,
                "ORBITAL STRIKE");
    }

    public static void schedule(ServerLevel level, ServerPlayer owner, Vec3 target,
                                int delay, double radius, float damage, boolean terrainDamage, String label) {
        PENDING.add(new PendingStrike(level.dimension(), target, owner.getUUID(), delay,
                radius, damage, terrainDamage, label));
        owner.sendOverlayMessage(Component.literal("§b" + label + " §8// §fTARGET LOCKED §8// §eIMPACT IN "
                + String.format("%.1f", delay / 20.0) + "s"));
        renderTargetLock(level, target, delay);
        level.playSound(null, BlockPos.containing(target), ModSounds.TARGET_LOCK,
                SoundSource.PLAYERS, 1.7F, 0.78F);
    }

    public static void tick(MinecraftServer server) {
        Iterator<PendingStrike> iterator = PENDING.iterator();
        while (iterator.hasNext()) {
            PendingStrike strike = iterator.next();
            ServerLevel level = server.getLevel(strike.dimension);
            if (level == null) {
                iterator.remove();
                continue;
            }

            strike.ticksRemaining--;
            if (strike.ticksRemaining > 0) {
                if (strike.ticksRemaining % 5 == 0) renderTargetLock(level, strike.position, strike.ticksRemaining);
                if (strike.ticksRemaining == 20) {
                    ServerPlayer owner = server.getPlayerList().getPlayer(strike.owner);
                    if (owner != null) owner.sendOverlayMessage(Component.literal("§e" + strike.label + " §8// §f1 SECOND TO IMPACT"));
                }
                continue;
            }

            detonate(level, strike, server.getPlayerList().getPlayer(strike.owner));
            iterator.remove();
        }
    }

    private static void renderTargetLock(ServerLevel level, Vec3 center, int ticksRemaining) {
        double radius = 2.6 + (ticksRemaining % 20) * 0.025;
        for (int i = 0; i < 16; i++) {
            double angle = (Math.PI * 2.0 * i / 16.0) + (ticksRemaining * 0.035);
            double x = center.x + Math.cos(angle) * radius;
            double z = center.z + Math.sin(angle) * radius;
            level.sendParticles(ParticleTypes.END_ROD, x, center.y + 0.05, z, 1, 0, 0, 0, 0);
        }
        if (ticksRemaining % 10 == 0) {
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, center.x, center.y + 0.2, center.z,
                    5, 0.35, 0.25, 0.35, 0.02);
        }
    }

    private static void detonate(ServerLevel level, PendingStrike strike, ServerPlayer owner) {
        Vec3 center = strike.position;
        double radius = strike.radius;
        level.sendParticles(ParticleTypes.FLASH, center.x, center.y, center.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.CLOUD, center.x, center.y, center.z, 95, 2.1, 1.0, 2.1, 0.14);
        level.sendParticles(ParticleTypes.FLAME, center.x, center.y, center.z, 110, 1.8, 0.9, 1.8, 0.11);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, center.x, center.y, center.z, 140, 2.0, 1.2, 2.0, 0.2);
        level.playSound(null, BlockPos.containing(center), ModSounds.ORBITAL_IMPACT,
                SoundSource.BLOCKS, 5.0F, strike.radius > 12.0 ? 0.52F : 0.72F);

        AABB area = AABB.ofSize(center, radius * 2.0, radius * 2.0, radius * 2.0);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area, LivingEntity::isAlive)) {
            if (owner != null && entity.getUUID().equals(owner.getUUID())) continue;
            if (owner != null && entity instanceof ServerPlayer targetPlayer && !owner.canHarmPlayer(targetPlayer)) continue;
            double distance = entity.position().distanceTo(center);
            if (distance > radius) continue;
            float falloff = (float) Math.max(0.12, 1.0 - (distance / radius) * 0.78);
            entity.hurtServer(level, owner == null ? level.damageSources().generic() : level.damageSources().playerAttack(owner), strike.damage * falloff);
            Vec3 away = entity.position().subtract(center).normalize().scale(2.2 * falloff);
            entity.push(away.x, 0.9 * falloff, away.z);
        }

        if (strike.terrainDamage && (owner == null || owner.getAbilities().mayBuild)) {
            destroyImpactTerrain(level, center, radius, owner);
        }
        for (int ring = 0; ring < 4; ring++) {
            double ringRadius = radius * (0.30 + ring * 0.18);
            double y = center.y + 0.15 + ring * 0.18;
            for (int i = 0; i < 32; i++) {
                double angle = Math.PI * 2.0 * i / 32.0;
                double x = center.x + Math.cos(angle) * ringRadius;
                double z = center.z + Math.sin(angle) * ringRadius;
                level.sendParticles(ParticleTypes.POOF, x, y, z, 1, 0.025, 0.08, 0.025, 0.02);
            }
        }
        if (owner != null) owner.sendOverlayMessage(Component.literal("§6" + strike.label + " §8// §fIMPACT CONFIRMED"));
    }

    private static void destroyImpactTerrain(ServerLevel level, Vec3 center, double radius, ServerPlayer owner) {
        int extent = (int) Math.ceil(Math.min(radius * 0.72, 10.0));
        BlockPos origin = BlockPos.containing(center);
        int checks = 0;
        for (int x = -extent; x <= extent; x++) {
            for (int y = -extent; y <= extent; y++) {
                for (int z = -extent; z <= extent; z++) {
                    if (++checks > 7000) return;
                    double distance = Math.sqrt(x * x + y * y * 0.7 + z * z);
                    if (distance > radius * 0.72) continue;
                    BlockPos pos = origin.offset(x, y, z);
                    var state = level.getBlockState(pos);
                    if (state.isAir()) continue;
                    float hardness = state.getDestroySpeed(level, pos);
                    if (hardness < 0.0F || hardness > 18.0F) continue;
                    float chance = (float) (0.82 - distance / (radius * 1.65));
                    if (Math.random() < chance) level.destroyBlock(pos, true, owner);
                }
            }
        }
    }

    private static final class PendingStrike {
        private final ResourceKey<Level> dimension;
        private final Vec3 position;
        private final UUID owner;
        private final double radius;
        private final float damage;
        private final boolean terrainDamage;
        private final String label;
        private int ticksRemaining;

        private PendingStrike(ResourceKey<Level> dimension, Vec3 position, UUID owner, int delay,
                              double radius, float damage, boolean terrainDamage, String label) {
            this.dimension = dimension;
            this.position = position;
            this.owner = owner;
            this.ticksRemaining = delay;
            this.radius = radius;
            this.damage = damage;
            this.terrainDamage = terrainDamage;
            this.label = label;
        }
    }
}
