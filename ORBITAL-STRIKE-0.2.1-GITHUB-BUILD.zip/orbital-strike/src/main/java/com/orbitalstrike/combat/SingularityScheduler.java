package com.orbitalstrike.combat;

import com.orbitalstrike.sound.ModSounds;
import com.orbitalstrike.config.OrbitalConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** Temporary black-hole effect. All attraction and damage are computed on the server. */
public final class SingularityScheduler {
    private static final List<Singularity> ACTIVE = new ArrayList<>();
    private SingularityScheduler() {}

    public static void create(ServerLevel level, ServerPlayer owner, Vec3 center) {
        ACTIVE.add(new Singularity(level.dimension(), center, owner.getUUID(), 80));
        owner.sendOverlayMessage(Component.literal("§5SINGULARITY §8// §fGRAVITY WELL DEPLOYED"));
        level.playSound(null, BlockPos.containing(center), ModSounds.SINGULARITY,
                SoundSource.PLAYERS, 2.2F, 0.68F);
    }

    public static void tick(MinecraftServer server) {
        Iterator<Singularity> iterator = ACTIVE.iterator();
        while (iterator.hasNext()) {
            Singularity singularity = iterator.next();
            ServerLevel level = server.getLevel(singularity.dimension);
            if (level == null) { iterator.remove(); continue; }
            singularity.ticks--;
            Vec3 center = singularity.center;
            double progress = 1.0 - singularity.ticks / 80.0;
            double radius = 10.0 - progress * 2.0;
            if (singularity.ticks % 2 == 0) {
                for (int i = 0; i < 18; i++) {
                    double angle = i * Math.PI * 2.0 / 18.0 + singularity.ticks * 0.12;
                    double ring = radius * (0.75 + 0.08 * Math.sin(singularity.ticks * 0.18 + i));
                    level.sendParticles(ParticleTypes.PORTAL,
                            center.x + Math.cos(angle) * ring, center.y + 0.25,
                            center.z + Math.sin(angle) * ring, 1, 0.04, 0.12, 0.04, 0.02);
                }
                level.sendParticles(ParticleTypes.REVERSE_PORTAL, center.x, center.y, center.z,
                        10, 0.35, 0.35, 0.35, 0.12);
                AABB bounds = AABB.ofSize(center, radius * 2.0, radius * 2.0, radius * 2.0);
                ServerPlayer owner = server.getPlayerList().getPlayer(singularity.owner);
                for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, bounds, LivingEntity::isAlive)) {
                    if (owner != null && entity.getUUID().equals(owner.getUUID())) continue;
                    if (owner != null && entity instanceof ServerPlayer target && !owner.canHarmPlayer(target)) continue;
                    Vec3 pull = center.subtract(entity.position());
                    double distance = Math.max(1.2, pull.length());
                    double strength = Math.min(0.42, 3.2 / distance);
                    Vec3 impulse = pull.normalize().scale(strength);
                    entity.push(impulse.x, impulse.y + 0.025, impulse.z);
                    if (singularity.ticks % 20 == 0) {
                        entity.hurtServer(level, owner == null ? level.damageSources().generic() : level.damageSources().playerAttack(owner), (float)(2.0F * OrbitalConfig.specialDamageMultiplier));
                    }
                }
            }
            if (singularity.ticks <= 0) {
                level.sendParticles(ParticleTypes.FLASH, center.x, center.y, center.z, 1, 0, 0, 0, 0);
                level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
                level.sendParticles(ParticleTypes.DRAGON_BREATH, center.x, center.y, center.z,
                        90, 1.2, 0.8, 1.2, 0.1);
                level.playSound(null, BlockPos.containing(center), ModSounds.ORBITAL_IMPACT,
                        SoundSource.BLOCKS, 3.0F, 0.55F);
                AABB bounds = AABB.ofSize(center, 9.0, 9.0, 9.0);
                ServerPlayer owner = server.getPlayerList().getPlayer(singularity.owner);
                for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, bounds, LivingEntity::isAlive)) {
                    if (owner != null && entity.getUUID().equals(owner.getUUID())) continue;
                    if (owner != null && entity instanceof ServerPlayer target && !owner.canHarmPlayer(target)) continue;
                    if (entity.position().distanceTo(center) <= 4.5) {
                        entity.hurtServer(level, owner == null ? level.damageSources().generic() : level.damageSources().playerAttack(owner), (float)(18.0F * OrbitalConfig.specialDamageMultiplier));
                    }
                }
                if (owner != null) owner.sendOverlayMessage(Component.literal("§5SINGULARITY §8// §fCOLLAPSE COMPLETE"));
                iterator.remove();
            }
        }
    }

    private static final class Singularity {
        private final ResourceKey<Level> dimension;
        private final Vec3 center;
        private final UUID owner;
        private int ticks;
        private Singularity(ResourceKey<Level> dimension, Vec3 center, UUID owner, int ticks) {
            this.dimension = dimension; this.center = center; this.owner = owner; this.ticks = ticks;
        }
    }
}
