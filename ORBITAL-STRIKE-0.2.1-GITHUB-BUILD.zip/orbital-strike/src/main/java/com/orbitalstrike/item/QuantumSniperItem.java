package com.orbitalstrike.item;

import com.orbitalstrike.combat.WeaponTargeting;
import com.orbitalstrike.config.OrbitalConfig;
import com.orbitalstrike.sound.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class QuantumSniperItem extends Item {
    public QuantumSniperItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player user, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.PASS;
        if (!(level instanceof ServerLevel serverLevel) || !(user instanceof ServerPlayer player)) {
            return InteractionResult.FAIL;
        }

        player.getCooldowns().addCooldown(this, OrbitalConfig.sniperCooldownTicks);
        Vec3 start = player.getEyePosition();
        WeaponTargeting.Target target = WeaponTargeting.acquire(serverLevel, player, OrbitalConfig.sniperRange);
        Vec3 end = target == null ? WeaponTargeting.blockAim(player, OrbitalConfig.sniperRange) : target.hitPoint();

        int segments = 42;
        for (int i = 0; i <= segments; i++) {
            Vec3 point = start.lerp(end, i / (double) segments);
            serverLevel.sendParticles(ParticleTypes.END_ROD, point.x, point.y, point.z,
                    1, 0.005, 0.005, 0.005, 0.0);
        }
        serverLevel.sendParticles(ParticleTypes.FLASH, end.x, end.y, end.z, 1, 0, 0, 0, 0);
        serverLevel.sendParticles(ParticleTypes.ELECTRIC_SPARK, end.x, end.y, end.z,
                18, 0.18, 0.18, 0.18, 0.06);
        serverLevel.playSound(null, player.blockPosition(), ModSounds.QUANTUM_FIRE,
                SoundSource.PLAYERS, 1.25F, 0.78F);

        if (target != null) {
            boolean allowed = !(target.entity() instanceof ServerPlayer targetPlayer) || player.canHarmPlayer(targetPlayer);
            if (allowed) {
                target.entity().hurtServer(serverLevel, serverLevel.damageSources().playerAttack(player), OrbitalConfig.sniperDamage);
                target.entity().setSecondsOnFire(1);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
