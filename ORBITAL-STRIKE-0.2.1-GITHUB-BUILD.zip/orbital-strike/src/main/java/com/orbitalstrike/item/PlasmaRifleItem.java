package com.orbitalstrike.item;

import com.orbitalstrike.combat.WeaponTargeting;
import com.orbitalstrike.config.OrbitalConfig;
import com.orbitalstrike.sound.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class PlasmaRifleItem extends Item {
    public PlasmaRifleItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player user, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.PASS;
        if (!(level instanceof ServerLevel serverLevel) || !(user instanceof ServerPlayer player)) {
            return InteractionResult.FAIL;
        }

        player.getCooldowns().addCooldown(this, OrbitalConfig.plasmaCooldownTicks);
        Vec3 start = player.getEyePosition();
        Vec3 direction = player.getViewVector(1.0F).normalize();
        WeaponTargeting.Target target = WeaponTargeting.acquire(serverLevel, player, OrbitalConfig.plasmaRange);
        Vec3 end = target == null ? WeaponTargeting.blockAim(player, OrbitalConfig.plasmaRange) : target.hitPoint();

        emitBeam(serverLevel, start, end, ParticleTypes.ELECTRIC_SPARK, 22);
        serverLevel.sendParticles(ParticleTypes.FLAME, end.x, end.y, end.z, 8, 0.12, 0.12, 0.12, 0.015);
        serverLevel.playSound(null, player.blockPosition(), ModSounds.PLASMA_FIRE,
                SoundSource.PLAYERS, 1.05F, 0.92F + serverLevel.random.nextFloat() * 0.12F);

        if (target != null) {
            LivingEntity victim = target.entity();
            boolean allowed = !(victim instanceof ServerPlayer targetPlayer) || player.canHarmPlayer(targetPlayer);
            if (allowed) {
                victim.hurtServer(serverLevel, serverLevel.damageSources().playerAttack(player), OrbitalConfig.plasmaDamage);
                victim.setSecondsOnFire(2);
                serverLevel.sendParticles(ParticleTypes.CRIT, end.x, end.y, end.z, 10, 0.22, 0.22, 0.22, 0.08);
            }
        }
        return InteractionResult.SUCCESS;
    }

    private static void emitBeam(ServerLevel level, Vec3 start, Vec3 end,
                                 net.minecraft.core.particles.ParticleOptions particle, int segments) {
        for (int i = 0; i <= segments; i++) {
            Vec3 point = start.lerp(end, i / (double) segments);
            level.sendParticles(particle, point.x, point.y, point.z, 1, 0.015, 0.015, 0.015, 0.0);
        }
    }
}
