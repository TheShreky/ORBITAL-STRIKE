"""Generate deterministic low-poly ORBITAL STRIKE item models, pixel textures and OGG SFX.
Requires Pillow, NumPy and FFmpeg. Generated outputs are committed in src/main/resources.
"""
from pathlib import Path
import json, math, random, wave, subprocess
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).parent
ASSETS = ROOT / 'src/main/resources/assets/orbital_strike'
TEX = ASSETS / 'textures/item'
MODELS = ASSETS / 'models/item'
ITEMS = ASSETS / 'items'
SOUNDS = ASSETS / 'sounds'
for p in (TEX, MODELS, ITEMS, SOUNDS): p.mkdir(parents=True, exist_ok=True)

PALETTE = {
    'dark': ('metal_dark', (22, 33, 48)),
    'metal': ('metal_light', (103, 132, 151)),
    'rubber': ('rubber', (13, 18, 26)),
    'cyan': ('energy_cyan', (20, 215, 255)),
    'blue': ('energy_blue', (48, 100, 255)),
    'violet': ('energy_violet', (172, 68, 255)),
    'amber': ('amber', (255, 170, 48)),
    'alloy': ('alloy', (168, 185, 198)),
    'red': ('energy_red', (255, 55, 48)),
    'green': ('energy_green', (70, 255, 145)),
}

# Distinct seamless pixel material tiles.
for key, (filename, base) in PALETTE.items():
    im = Image.new('RGBA', (16, 16), (*base, 255)); px = im.load()
    rng = random.Random('orbital-strike-' + key)
    for y in range(16):
        for x in range(16):
            n = rng.randint(-12, 12)
            fac = 1.12 if (x + y) % 7 == 0 else 1.0
            px[x, y] = tuple(max(0, min(255, int(c*fac+n))) for c in base) + (255,)
    d = ImageDraw.Draw(im)
    d.line((0, 15, 15, 15), fill=(4, 7, 12, 255))
    if key in ('cyan','blue','violet','red','green'):
        d.rectangle((2,2,13,13), outline=tuple(min(255,c+35) for c in base)+(255,))
        d.line((4,8,11,8), fill=(235,255,255,255), width=1)
        d.point((8,5), fill=(255,255,255,255))
    im.save(TEX / f'{filename}.png')

# Model helpers use vanilla 16-unit block model coordinates.
def faces(tex):
    return {face: {'uv':[0,0,16,16], 'texture':'#'+tex} for face in ('north','south','east','west','up','down')}
def cube(a,b,tex): return {'from':a,'to':b,'faces':faces(tex)}
TEXTURES = {'dark':'orbital_strike:item/metal_dark','metal':'orbital_strike:item/metal_light',
            'rubber':'orbital_strike:item/rubber','cyan':'orbital_strike:item/energy_cyan',
            'blue':'orbital_strike:item/energy_blue','violet':'orbital_strike:item/energy_violet',
            'amber':'orbital_strike:item/amber','alloy':'orbital_strike:item/alloy',
            'red':'orbital_strike:item/energy_red','green':'orbital_strike:item/energy_green'}
DISPLAY = {
 'gui': {'rotation':[25,225,0], 'translation':[0,0,0], 'scale':[0.9,0.9,0.9]},
 'ground': {'translation':[0,2,0], 'scale':[0.52,0.52,0.52]},
 'fixed': {'rotation':[0,180,0], 'translation':[0,0,0], 'scale':[0.8,0.8,0.8]},
 'thirdperson_righthand': {'rotation':[0,-90,55], 'translation':[1.0,3.0,1.0], 'scale':[0.82,0.82,0.82]},
 'thirdperson_lefthand': {'rotation':[0,90,-55], 'translation':[1.0,3.0,1.0], 'scale':[0.82,0.82,0.82]},
 'firstperson_righthand': {'rotation':[0,-90,25], 'translation':[1.0,3.0,1.2], 'scale':[0.72,0.72,0.72]},
 'firstperson_lefthand': {'rotation':[0,90,-25], 'translation':[1.0,3.0,1.2], 'scale':[0.72,0.72,0.72]}
}

# Weapon bodies are recognizable from the inventory and third-person views.
models = {
 'orbital_laser_cannon': [
  cube([2,6,5],[13,11,11],'dark'), cube([8,8,6],[16,10,10],'metal'),
  cube([14,7,6],[16,9,10],'red'), cube([4,2,6],[8,6,10],'rubber'),
  cube([5,11,5],[11,14,11],'metal'), cube([6,12,6],[10,13,10],'red'),
  cube([1,7,4],[3,10,12],'alloy')],
 'heavy_railgun': [
  cube([1,6,5],[12,10,11],'dark'), cube([8,8,7],[16,10,9],'metal'),
  cube([14,7,7],[16,9,9],'blue'), cube([3,2,6],[7,6,10],'rubber'),
  cube([4,10,5],[12,13,11],'metal'), cube([7,11,6],[11,12,10],'blue'),
  cube([0,7,6],[2,9,10],'alloy')],
 'energy_sword': [
  cube([6,1,6],[10,7,10],'rubber'), cube([5,5,5],[11,7,11],'dark'),
  cube([7,7,6],[9,14,10],'metal'), cube([7,13,6],[9,16,10],'cyan'),
  cube([6,6,5],[10,8,11],'amber')],
 'nuclear_bombardment': [
  cube([3,5,5],[13,12,11],'dark'), cube([6,2,6],[10,6,10],'rubber'),
  cube([5,10,4],[11,14,12],'metal'), cube([6,11,3],[10,13,4],'red'),
  cube([7,11,12],[9,13,14],'red'), cube([4,7,2],[12,9,4],'amber'),
  cube([5,6,12],[11,10,15],'alloy')],
 'gravity_manipulator': [
  cube([3,4,5],[13,12,11],'dark'), cube([5,2,6],[10,5,10],'rubber'),
  cube([5,10,4],[11,13,12],'metal'), cube([6,7,2],[10,10,4],'violet'),
  cube([6,7,12],[10,10,15],'violet'), cube([7,8,14],[9,9,16],'cyan')],
 'rocket_launcher': [
  cube([2,5,4],[13,12,12],'dark'), cube([8,7,5],[16,10,11],'metal'),
  cube([14,7,6],[16,9,10],'amber'), cube([4,2,6],[8,6,10],'rubber'),
  cube([4,11,4],[12,14,12],'metal'), cube([5,12,5],[11,13,11],'red'),
  cube([1,6,4],[3,10,12],'alloy')],
 'drone_missile_system': [
  cube([3,5,4],[12,11,12],'dark'), cube([5,2,6],[10,5,10],'rubber'),
  cube([6,10,4],[10,14,12],'metal'), cube([4,7,1],[12,9,4],'blue'),
  cube([4,7,12],[12,9,15],'blue'), cube([7,8,14],[9,9,16],'cyan'),
  cube([1,6,6],[3,10,10],'amber')],
 'black_hole_launcher': [
  cube([2,5,4],[13,12,12],'dark'), cube([8,7,5],[16,10,11],'metal'),
  cube([14,6,6],[16,10,10],'violet'), cube([4,2,6],[8,6,10],'rubber'),
  cube([5,10,4],[11,14,12],'metal'), cube([6,11,3],[10,13,4],'violet'),
  cube([6,11,12],[10,13,15],'violet')],
 'emp_cannon': [
  cube([2,5,4],[13,12,12],'dark'), cube([8,7,5],[16,10,11],'metal'),
  cube([14,6,6],[16,10,10],'cyan'), cube([4,2,6],[8,6,10],'rubber'),
  cube([5,10,4],[11,14,12],'metal'), cube([6,11,3],[10,13,4],'cyan'),
  cube([6,11,12],[10,13,15],'cyan')],
 'particle_accelerator': [
  cube([1,6,5],[13,10,11],'dark'), cube([8,8,6],[16,10,10],'metal'),
  cube([14,7,6],[16,9,10],'green'), cube([3,2,6],[7,6,10],'rubber'),
  cube([4,10,4],[12,13,12],'metal'), cube([6,11,5],[10,12,11],'green'),
  cube([0,7,6],[2,9,10],'alloy')]
}
for name, elements in models.items():
    # Each model's particle sprite must resolve even though its visible faces use palette materials.
    icon_color = {'orbital_laser_cannon': PALETTE['red'][1], 'heavy_railgun': PALETTE['blue'][1],
                  'energy_sword': PALETTE['cyan'][1], 'nuclear_bombardment': PALETTE['red'][1],
                  'gravity_manipulator': PALETTE['violet'][1], 'rocket_launcher': PALETTE['amber'][1],
                  'drone_missile_system': PALETTE['blue'][1], 'black_hole_launcher': PALETTE['violet'][1],
                  'emp_cannon': PALETTE['cyan'][1], 'particle_accelerator': PALETTE['green'][1]}[name]
    tile = Image.new('RGBA',(16,16),(*icon_color,255)); td=ImageDraw.Draw(tile)
    td.rectangle((1,1,14,14),outline=(235,250,255,255),width=1)
    td.line((3,8,12,8),fill=(255,255,255,255),width=2)
    tile.save(TEX/f'{name}.png')
    data={'credit':'ORBITAL STRIKE Studio','gui_light':'front','textures':dict(TEXTURES),
          'elements':elements,'display':DISPLAY}
    data['textures']['particle']=f'orbital_strike:item/{name}'
    (MODELS/f'{name}.json').write_text(json.dumps(data,indent=2)+'\n')
    (ITEMS/f'{name}.json').write_text(json.dumps({'model':{'type':'minecraft:model','model':f'orbital_strike:item/{name}'}},indent=2)+'\n')

# Component models.
for name, material in [('quantum_core','violet'),('plasma_cell','cyan'),('orbital_circuit','amber')]:
    tile = Image.new('RGBA',(16,16),(*PALETTE[material][1],255)); td=ImageDraw.Draw(tile)
    td.rectangle((2,2,13,13),outline=(245,255,255,255),width=1); td.point((7,7),fill=(255,255,255,255))
    tile.save(TEX/f'{name}.png')
    els=[cube([3,3,3],[13,13,13],'dark'),cube([5,5,5],[11,11,11],material),
         cube([6,6,2],[10,10,4],'metal'),cube([6,6,12],[10,10,14],'metal')]
    data={'credit':'ORBITAL STRIKE Studio','gui_light':'front','textures':dict(TEXTURES),
          'elements':els,'display':DISPLAY}
    data['textures']['particle']=f'orbital_strike:item/{name}'
    (MODELS/f'{name}.json').write_text(json.dumps(data,indent=2)+'\n')
    (ITEMS/f'{name}.json').write_text(json.dumps({'model':{'type':'minecraft:model','model':f'orbital_strike:item/{name}'}},indent=2)+'\n')

# Create 64x64 crisp item art used as a recognizable GUI/guide icon as well as texture basis.
# Every weapon receives its own icon texture in the item's icon folder.
ICON_DIR=ASSETS/'textures/gui'
ICON_DIR.mkdir(parents=True,exist_ok=True)
icon_colors={'orbital_laser_cannon':(255,65,54),'heavy_railgun':(55,130,255),'energy_sword':(35,230,255),
'nuclear_bombardment':(255,90,45),'gravity_manipulator':(182,80,255),'rocket_launcher':(255,170,45),
'drone_missile_system':(75,170,255),'black_hole_launcher':(160,65,240),'emp_cannon':(50,235,255),
'particle_accelerator':(80,255,150)}
for name,color in icon_colors.items():
    im=Image.new('RGBA',(64,64),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.ellipse((6,6,58,58),fill=(8,16,28,235),outline=color+(255,),width=3)
    d.ellipse((13,13,51,51),outline=(130,165,190,220),width=1)
    # angular weapon glyph with distinct energy core and barrel
    d.polygon([(12,34),(22,24),(46,18),(54,23),(49,31),(27,40),(20,42)],fill=(38,52,69,255),outline=(188,210,225,255))
    d.rectangle((39,20,57,25),fill=color+(255,),outline=(235,250,255,255),width=1)
    d.polygon([(20,39),(31,38),(29,54),(19,54)],fill=(16,22,31,255),outline=(120,145,165,255))
    d.ellipse((27,27,37,37),fill=color+(255,),outline=(240,255,255,255),width=1)
    for i in range(3): d.line((28+i*4,29,32+i*4,35),fill=(245,255,255,180),width=1)
    im.save(ICON_DIR/f'{name}.png')

# Six original sci-fi sound effects; mono 48 kHz Vorbis for low file size.
SR=48000
rng=np.random.default_rng(26302)
def encode(name, samples):
    samples=np.asarray(samples,dtype=np.float32)
    peak=max(1e-6,float(np.max(np.abs(samples))))
    samples=np.clip(samples/peak*0.82,-1,1)
    wav=SOUNDS/f'{name}.wav'; ogg=SOUNDS/f'{name}.ogg'
    pcm=(samples*32767).astype(np.int16)
    with wave.open(str(wav),'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes(pcm.tobytes())
    subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(wav),'-c:a','libvorbis','-q:a','5',str(ogg)],check=True)
    wav.unlink(missing_ok=True)

t=np.arange(int(SR*0.9))/SR
laser=(np.sin(2*np.pi*(190+2100*t)*t)*np.exp(-3.0*t)*0.65 + rng.normal(0,.22,len(t))*np.exp(-17*t))
encode('orbital_laser',laser)
t=np.arange(int(SR*0.62))/SR
rail=(np.sin(2*np.pi*(90+3200*t)*t)*np.exp(-6*t)*.55 + rng.normal(0,.55,len(t))*np.exp(-24*t))
encode('railgun_fire',rail)
t=np.arange(int(SR*0.38))/SR
blade=(np.sin(2*np.pi*(800-500*t)*t)*np.exp(-4*t)*.4 + rng.normal(0,.3,len(t))*np.exp(-13*t))
encode('blade_swing',blade)
t=np.arange(int(SR*1.6))/SR
missile=(np.sin(2*np.pi*(80-24*t)*t)*np.exp(-2.8*t)*.65 + rng.normal(0,.45,len(t))*np.exp(-4*t) + np.sin(2*np.pi*130*t)*np.exp(-7*t)*.2)
encode('missile_impact',missile)
t=np.arange(int(SR*2.4))/SR
sing=(np.sin(2*np.pi*(45+120*np.exp(-t)*np.sin(2*np.pi*.8*t))*t)*np.exp(-.8*t)*.4 + np.sin(2*np.pi*33*t)*np.exp(-.9*t)*.3 + rng.normal(0,.2,len(t))*np.exp(-1.8*t))
encode('singularity',sing)
t=np.arange(int(SR*0.75))/SR
emp=(np.sin(2*np.pi*(120-80*t)*t)*np.exp(-5*t)*.45 + rng.normal(0,.7,len(t))*np.exp(-22*t) + np.sin(2*np.pi*1900*t)*np.exp(-18*t)*.2)
encode('emp_blast',emp)

print('Generated',len(models),'weapon models, 3 component models,',len(models)+3,'item definitions and 6 sounds.')
