#!/usr/bin/env sh
set -eu

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java 25 JDK is required." >&2
  exit 1
fi
if ! java -version 2>&1 | grep -q '25'; then
  echo "ERROR: Java 25 is required." >&2
  java -version
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle 9.8.2 is required on PATH." >&2
  exit 1
fi
if ! gradle --version 2>&1 | grep -q 'Gradle 9.8.2'; then
  echo "ERROR: This project is pinned to Gradle 9.8.2." >&2
  gradle --version
  exit 1
fi
gradle build --no-configuration-cache
