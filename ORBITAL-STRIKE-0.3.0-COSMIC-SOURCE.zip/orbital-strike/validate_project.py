#!/usr/bin/env python3
"""Pre-build validation for ORBITAL STRIKE resources and 26.3 recipe data."""
from __future__ import annotations

import json
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RES = ROOT / "src/main/resources"
errors: list[str] = []


def read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"Invalid JSON {path.relative_to(ROOT)}: {exc}")
        return None


def png_size(path: Path):
    try:
        with path.open("rb") as stream:
            header = stream.read(24)
        if header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
            raise ValueError("missing PNG IHDR")
        return struct.unpack(">II", header[16:24])
    except Exception as exc:
        errors.append(f"Invalid PNG {path.relative_to(ROOT)}: {exc}")
        return None


metadata = read_json(RES / "fabric.mod.json")
if not isinstance(metadata, dict) or metadata.get("id") != "orbital_strike":
    errors.append("fabric.mod.json is missing mod id orbital_strike")

# Parse every JSON resource first; malformed data files can prevent a world from loading.
for path in RES.rglob("*.json"):
    read_json(path)

# Validate shaped crafting recipe ingredients. Keep each ingredient as an object;
# bare strings here are not silently rewritten by the build workflow.
recipe_dir = RES / "data/orbital_strike/recipe"
recipe_count = 0
if recipe_dir.exists():
    for path in sorted(recipe_dir.glob("*.json")):
        data = read_json(path)
        if not isinstance(data, dict):
            continue
        if data.get("type") == "minecraft:crafting_shaped":
            recipe_count += 1
            pattern = data.get("pattern")
            key = data.get("key")
            result = data.get("result")
            if not isinstance(pattern, list) or not pattern or any(not isinstance(row, str) for row in pattern):
                errors.append(f"Bad shaped recipe pattern: {path.name}")
            if not isinstance(key, dict) or not key:
                errors.append(f"Missing recipe key map: {path.name}")
            else:
                for symbol, ingredient in key.items():
                    if not isinstance(symbol, str) or len(symbol) != 1:
                        errors.append(f"Recipe key must use one-character symbols: {path.name}")
                    if not isinstance(ingredient, dict) or not ("item" in ingredient or "tag" in ingredient):
                        errors.append(f"Recipe ingredient {symbol!r} must be an item/tag object: {path.name}")
            if not isinstance(result, dict) or not isinstance(result.get("id"), str):
                errors.append(f"Recipe result is missing its item id: {path.name}")
if recipe_count == 0:
    errors.append("No shaped recipes found under data/orbital_strike/recipe")


# Validate that every declared custom sound has a matching OGG resource.
sounds_path = RES / "assets/orbital_strike/sounds.json"
sounds_data = read_json(sounds_path) if sounds_path.exists() else None
if isinstance(sounds_data, dict):
    for sound_name, definition in sounds_data.items():
        if not isinstance(definition, dict):
            errors.append(f"Bad sound definition: {sound_name}")
            continue
        for sound_entry in definition.get("sounds", []):
            if isinstance(sound_entry, str):
                resource = sound_entry.split(":", 1)[-1]
                ogg_path = RES / f"assets/orbital_strike/sounds/{resource}.ogg"
                if not ogg_path.exists():
                    errors.append(f"Missing sound resource for {sound_name}: {ogg_path.relative_to(ROOT)}")
                elif not ogg_path.read_bytes().startswith(b"OggS"):
                    errors.append(f"Invalid OGG header: {ogg_path.relative_to(ROOT)}")

# Check item model texture references and animated sprite metadata.
model_dir = RES / "assets/orbital_strike/models/item"
for path in model_dir.glob("*.json"):
    data = read_json(path)
    if not isinstance(data, dict):
        continue
    for texture in data.get("textures", {}).values():
        if isinstance(texture, str) and texture.startswith("orbital_strike:item/"):
            name = texture.split("/", 1)[1]
            texture_path = RES / f"assets/orbital_strike/textures/item/{name}.png"
            if not texture_path.exists():
                errors.append(f"Missing model texture {texture_path.relative_to(ROOT)}")

animated_count = 0
for meta_path in RES.rglob("*.png.mcmeta"):
    data = read_json(meta_path)
    if not isinstance(data, dict):
        continue
    animation = data.get("animation")
    png_path = Path(str(meta_path)[:-7])
    dimensions = png_size(png_path) if png_path.exists() else None
    if not png_path.exists():
        errors.append(f"Animation metadata has no PNG: {meta_path.relative_to(ROOT)}")
        continue
    if not isinstance(animation, dict):
        errors.append(f"Missing animation object: {meta_path.relative_to(ROOT)}")
        continue
    frames = animation.get("frames", [])
    if not isinstance(frames, list) or not frames:
        errors.append(f"Animation has no explicit frames: {meta_path.relative_to(ROOT)}")
        continue
    width, height = dimensions or (0, 0)
    # All animated textures in this project use square frame cells stacked vertically.
    if width <= 0 or height % width != 0:
        errors.append(f"Animated texture must be a vertical strip of square frames: {png_path.relative_to(ROOT)}")
        continue
    frame_total = height // width
    if any(not isinstance(index, int) or index < 0 or index >= frame_total for index in frames):
        errors.append(f"Animation frame index out of range: {meta_path.relative_to(ROOT)}")
    animated_count += 1

if errors:
    print("ORBITAL STRIKE resource validation FAILED:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"ORBITAL STRIKE resources OK: {recipe_count} recipes, {animated_count} animated textures, custom sound resources checked.")
