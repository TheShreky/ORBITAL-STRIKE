package com.orbitalstrike.item;

import com.orbitalstrike.combat.OrbitalStrikeScheduler;
import com.orbitalstrike.config.OrbitalConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permission;
import net.minecraft.server.permissions.PermissionLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class OrbitalDesignatorItem extends Item {
    public OrbitalDesignatorItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player user, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.PASS;
        if (!(level instanceof ServerLevel serverLevel) || !(user instanceof ServerPlayer player)) {
            return InteractionResult.FAIL;
        }
        if (OrbitalConfig.requireOperator && !player.permissions().hasPermission(
                new Permission.HasCommandLevel(PermissionLevel.GAMEMASTERS))) {
            player.sendOverlayMessage(Component.literal("§cORBITAL STRIKE // COMMAND AUTHORIZATION REQUIRED"));
            return InteractionResult.FAIL;
        }

        Vec3 target = player.pick(128.0D, 1.0F, false).getLocation();
        OrbitalStrikeScheduler.schedule(serverLevel, player, target);
        player.getCooldowns().addCooldown(player.getItemInHand(hand), OrbitalConfig.strikeCooldownTicks);
        return InteractionResult.SUCCESS;
    }
}
