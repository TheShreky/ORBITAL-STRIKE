package com.orbitalstrike.item;

import com.orbitalstrike.combat.WeaponTargeting;
import com.orbitalstrike.config.OrbitalConfig;
import com.orbitalstrike.effects.SpaceEffects;
import com.orbitalstrike.sound.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class PlasmaRifleItem extends Item {
    public PlasmaRifleItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult use(Level level, Player user, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.PASS;
        if (!(level instanceof ServerLevel serverLevel) || !(user instanceof ServerPlayer player)) {
            return InteractionResult.FAIL;
        }

        player.getCooldowns().addCooldown(player.getItemInHand(hand), OrbitalConfig.plasmaCooldownTicks);
        Vec3 start = player.getEyePosition();
        Vec3 direction = player.getViewVector(1.0F).normalize();
        WeaponTargeting.Target target = WeaponTargeting.acquire(serverLevel, player, OrbitalConfig.plasmaRange);
        Vec3 end = target == null ? WeaponTargeting.blockAim(player, OrbitalConfig.plasmaRange) : target.hitPoint();

        Vec3 side = new Vec3(-direction.z, 0, direction.x);
        if (side.lengthSqr() < 0.001) side = new Vec3(1, 0, 0);
        side = side.normalize().scale(0.075);
        emitBeam(serverLevel, start, end, ParticleTypes.ELECTRIC_SPARK, 28);
        SpaceEffects.beam(serverLevel, start.add(side), end.add(side), ParticleTypes.END_ROD, 24, 0.003);
        SpaceEffects.beam(serverLevel, start.subtract(side), end.subtract(side), ParticleTypes.SOUL_FIRE_FLAME, 24, 0.003);
        SpaceEffects.ring(serverLevel, start, 0.42, 18, ParticleTypes.FLAME, 0, 0.0);
        SpaceEffects.burst(serverLevel, end, ParticleTypes.FLAME, 14, 0.16, 0.025);
        serverLevel.playSound(null, player.blockPosition(), ModSounds.PLASMA_FIRE,
                SoundSource.PLAYERS, 1.05F, 0.92F + player.getRandom().nextFloat() * 0.12F);

        if (target != null) {
            LivingEntity victim = target.entity();
            boolean allowed = !(victim instanceof ServerPlayer targetPlayer) || player.canHarmPlayer(targetPlayer);
            if (allowed) {
                victim.hurtServer(serverLevel, serverLevel.damageSources().playerAttack(player), OrbitalConfig.plasmaDamage);
                victim.setRemainingFireTicks(40);
                serverLevel.sendParticles(ParticleTypes.CRIT, end.x, end.y, end.z, 16, 0.22, 0.22, 0.22, 0.08);
                SpaceEffects.ring(serverLevel, end, 0.8, 24, ParticleTypes.ELECTRIC_SPARK, 0.08, 0.2);
            }
        }
        return InteractionResult.SUCCESS;
    }

    private static void emitBeam(ServerLevel level, Vec3 start, Vec3 end,
                                 net.minecraft.core.particles.ParticleOptions particle, int segments) {
        for (int i = 0; i <= segments; i++) {
            Vec3 point = start.lerp(end, i / (double) segments);
            level.sendParticles(particle, point.x, point.y, point.z, 1, 0.015, 0.015, 0.015, 0.0);
        }
    }
}
