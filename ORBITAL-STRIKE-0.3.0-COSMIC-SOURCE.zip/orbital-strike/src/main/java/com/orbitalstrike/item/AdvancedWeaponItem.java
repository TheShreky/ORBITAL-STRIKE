package com.orbitalstrike.item;

import com.orbitalstrike.combat.OrbitalStrikeScheduler;
import com.orbitalstrike.config.OrbitalConfig;
import com.orbitalstrike.effects.SpaceEffects;
import com.orbitalstrike.combat.SingularityScheduler;
import com.orbitalstrike.combat.WeaponTargeting;
import com.orbitalstrike.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** One fully functional server-authoritative implementation shared by specialist weapon variants. */
public final class AdvancedWeaponItem extends Item {
    public enum Kind {
        ORBITAL_LASER(128, 90, 42, 2.8),
        HEAVY_RAILGUN(112, 36, 28, 0),
        ENERGY_SWORD(5.2, 8, 24, 0),
        NUCLEAR_BOMBARDMENT(160, 1200, 115, 19),
        GRAVITY_MANIPULATOR(48, 50, 0, 10),
        ROCKET_LAUNCHER(72, 52, 27, 4.8),
        DRONE_MISSILE(160, 220, 36, 6.0),
        BLACK_HOLE(64, 300, 18, 10),
        EMP_CANNON(48, 100, 10, 8.5),
        PARTICLE_ACCELERATOR(144, 80, 19, 0);

        public final double range;
        public final int cooldown;
        public final float damage;
        public final double radius;
        Kind(double range, int cooldown, float damage, double radius) {
            this.range = range; this.cooldown = cooldown; this.damage = damage; this.radius = radius;
        }
    }

    private final Kind kind;
    public AdvancedWeaponItem(Kind kind, Properties properties) { super(properties); this.kind = kind; }

    @Override
    public InteractionResult use(Level level, Player user, InteractionHand hand) {
        if (level.isClientSide()) return InteractionResult.PASS;
        if (!(level instanceof ServerLevel serverLevel) || !(user instanceof ServerPlayer player)) return InteractionResult.FAIL;
        if (player.getCooldowns().isOnCooldown(player.getItemInHand(hand))) return InteractionResult.FAIL;
        if (kind == Kind.NUCLEAR_BOMBARDMENT && OrbitalConfig.requireOperator
                && !player.permissions().hasPermission(new net.minecraft.server.permissions.Permission.HasCommandLevel(
                net.minecraft.server.permissions.PermissionLevel.GAMEMASTERS))) {
            player.sendOverlayMessage(net.minecraft.network.chat.Component.literal("§cNUCLEAR ORBITAL // COMMAND AUTHORIZATION REQUIRED"));
            return InteractionResult.FAIL;
        }

        List<WeaponTargeting.Target> targets = WeaponTargeting.acquireAll(serverLevel, player, kind.range);
        WeaponTargeting.Target first = targets.isEmpty() ? null : targets.getFirst();
        Vec3 start = player.getEyePosition();
        Vec3 aim = first == null ? WeaponTargeting.blockAim(player, kind.range) : first.hitPoint();
        int effectiveCooldown = Math.max(1, (int) Math.round(kind.cooldown * OrbitalConfig.specialCooldownMultiplier));
        player.getCooldowns().addCooldown(player.getItemInHand(hand), effectiveCooldown);

        switch (kind) {
            case ORBITAL_LASER -> orbitalLaser(serverLevel, player, start, aim);
            case HEAVY_RAILGUN -> piercingShot(serverLevel, player, start, aim, targets, 5, (float)(kind.damage * OrbitalConfig.specialDamageMultiplier), ParticleTypes.ELECTRIC_SPARK);
            case ENERGY_SWORD -> energySword(serverLevel, player, targets);
            case NUCLEAR_BOMBARDMENT -> OrbitalStrikeScheduler.schedule(serverLevel, player, aim,
                    100, kind.radius, (float)(kind.damage * OrbitalConfig.specialDamageMultiplier), OrbitalConfig.nuclearTerrainDamage, "NUCLEAR ORBITAL BOMBARDMENT");
            case GRAVITY_MANIPULATOR -> gravityPulse(serverLevel, player, aim);
            case ROCKET_LAUNCHER -> explosiveImpact(serverLevel, player, aim, kind.radius, (float)(kind.damage * OrbitalConfig.specialDamageMultiplier), "ROCKET IMPACT");
            case DRONE_MISSILE -> OrbitalStrikeScheduler.schedule(serverLevel, player, aim,
                    38, kind.radius, (float)(kind.damage * OrbitalConfig.specialDamageMultiplier), false, "DRONE MISSILE INBOUND");
            case BLACK_HOLE -> SingularityScheduler.create(serverLevel, player, aim);
            case EMP_CANNON -> empPulse(serverLevel, player, aim);
            case PARTICLE_ACCELERATOR -> piercingShot(serverLevel, player, start, aim, targets, 8, (float)(kind.damage * OrbitalConfig.specialDamageMultiplier), ParticleTypes.END_ROD);
        }
        return InteractionResult.SUCCESS;
    }

    private static void orbitalLaser(ServerLevel level, ServerPlayer player, Vec3 start, Vec3 end) {
        Vec3 direction = end.subtract(start).normalize();
        Vec3 side = new Vec3(-direction.z, 0, direction.x);
        if (side.lengthSqr() < 0.001) side = new Vec3(1, 0, 0);
        side = side.normalize().scale(0.13);
        SpaceEffects.beam(level, start, end, ParticleTypes.END_ROD, 64, 0.008);
        SpaceEffects.beam(level, start.add(side), end.add(side), ParticleTypes.ELECTRIC_SPARK, 52, 0.004);
        SpaceEffects.beam(level, start.subtract(side), end.subtract(side), ParticleTypes.SOUL_FIRE_FLAME, 52, 0.003);
        SpaceEffects.crosshair(level, end, 1.65, ParticleTypes.END_ROD, 0.35);
        SpaceEffects.burst(level, end, ParticleTypes.ELECTRIC_SPARK, 48, 0.32, 0.1);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, end.x, end.y, end.z, 1, 0, 0, 0, 0);
        level.playSound(null, player.blockPosition(), ModSounds.ORBITAL_LASER, SoundSource.PLAYERS, 1.7F, 0.7F);
        damageRadius(level, player, end, 2.8, (float)(42.0F * OrbitalConfig.specialDamageMultiplier), 0.35);
    }

    private static void piercingShot(ServerLevel level, ServerPlayer player, Vec3 start, Vec3 end,
                                     List<WeaponTargeting.Target> targets, int maxTargets, float damage,
                                     net.minecraft.core.particles.ParticleOptions particle) {
        Vec3 direction = end.subtract(start).normalize();
        Vec3 side = new Vec3(-direction.z, 0, direction.x);
        if (side.lengthSqr() < 0.001) side = new Vec3(1, 0, 0);
        side = side.normalize().scale(0.075);
        SpaceEffects.beam(level, start, end, particle, 58, 0.006);
        SpaceEffects.beam(level, start.add(side), end.add(side), ParticleTypes.END_ROD, 42, 0.002);
        SpaceEffects.beam(level, start.subtract(side), end.subtract(side), ParticleTypes.ELECTRIC_SPARK, 42, 0.002);
        SpaceEffects.crosshair(level, end, 1.0, ParticleTypes.ENCHANT, 0.0);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, end.x, end.y, end.z, 1, 0, 0, 0, 0);
        int hits = 0;
        for (WeaponTargeting.Target target : targets) {
            if (hits >= maxTargets) break;
            LivingEntity entity = target.entity();
            if (entity instanceof ServerPlayer targetPlayer && !player.canHarmPlayer(targetPlayer)) continue;
            if (entity.hurtServer(level, level.damageSources().playerAttack(player), damage)) hits++;
            Vec3 push = player.getViewVector(1.0F).scale(0.75);
            entity.push(push.x, push.y * 0.3, push.z);
            level.sendParticles(ParticleTypes.CRIT, target.hitPoint().x, target.hitPoint().y,
                    target.hitPoint().z, 8, 0.12, 0.12, 0.12, 0.04);
        }
        level.playSound(null, player.blockPosition(), ModSounds.RAILGUN_FIRE, SoundSource.PLAYERS, 1.5F, 0.8F);
    }

    private static void energySword(ServerLevel level, ServerPlayer player, List<WeaponTargeting.Target> targets) {
        if (targets.isEmpty() || targets.getFirst().distance() > 5.2) {
            player.sendOverlayMessage(net.minecraft.network.chat.Component.literal("§cENERGY SWORD // TARGET OUT OF RANGE"));
            return;
        }
        WeaponTargeting.Target target = targets.getFirst();
        LivingEntity victim = target.entity();
        if (!(victim instanceof ServerPlayer targetPlayer) || player.canHarmPlayer(targetPlayer)) {
            victim.hurtServer(level, level.damageSources().playerAttack(player), (float)(24.0F * OrbitalConfig.specialDamageMultiplier));
            victim.push(player.getViewVector(1.0F).x * 1.15, 0.28, player.getViewVector(1.0F).z * 1.15);
        }
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, target.hitPoint().x, target.hitPoint().y,
                target.hitPoint().z, 1, 0, 0, 0, 0);
        Vec3 forward = player.getViewVector(1.0F).normalize();
        Vec3 right = new Vec3(-forward.z, 0, forward.x);
        if (right.lengthSqr() < 0.001) right = new Vec3(1, 0, 0);
        right = right.normalize();
        for (int i = 0; i <= 24; i++) {
            double angle = -1.2 + (i / 24.0) * 2.4;
            Vec3 slash = target.hitPoint()
                    .add(right.scale(Math.cos(angle) * 0.95))
                    .add(0, Math.sin(angle) * 0.72, 0);
            level.sendParticles(ParticleTypes.END_ROD, slash.x, slash.y, slash.z, 1, 0, 0, 0, 0);
        }
        SpaceEffects.burst(level, target.hitPoint(), ParticleTypes.ELECTRIC_SPARK, 28, 0.28, 0.08);
        level.playSound(null, player.blockPosition(), ModSounds.BLADE_SWING, SoundSource.PLAYERS, 1.1F, 0.82F);
    }

    private static void gravityPulse(ServerLevel level, ServerPlayer player, Vec3 center) {
        SpaceEffects.ring(level, center, 3.1, 42, ParticleTypes.PORTAL, 0.08, 0.0);
        SpaceEffects.ringPlane(level, center, 2.45, 30, ParticleTypes.REVERSE_PORTAL, 0, 0.7, 1);
        SpaceEffects.ringPlane(level, center, 2.45, 30, ParticleTypes.END_ROD, 0, -0.7, 2);
        SpaceEffects.helix(level, center, 1.2, 4.0, 3, 28, ParticleTypes.SOUL_FIRE_FLAME, 0.0);
        SpaceEffects.burst(level, center, ParticleTypes.PORTAL, 75, 1.2, 0.12);
        level.playSound(null, BlockPos.containing(center), ModSounds.SINGULARITY, SoundSource.PLAYERS, 1.8F, 1.0F);
        AABB bounds = AABB.ofSize(center, 20, 20, 20);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, bounds, LivingEntity::isAlive)) {
            if (entity == player || (entity instanceof ServerPlayer target && !player.canHarmPlayer(target))) continue;
            Vec3 pull = center.subtract(entity.position());
            double distance = pull.length();
            if (distance > 10 || distance < 0.01) continue;
            Vec3 impulse = pull.normalize().scale(Math.min(1.1, 8.0 / distance));
            entity.push(impulse.x, impulse.y + 0.22, impulse.z);
        }
        player.sendOverlayMessage(net.minecraft.network.chat.Component.literal("§bGRAVITY MANIPULATOR // MASS PULL"));
    }

    private static void explosiveImpact(ServerLevel level, ServerPlayer player, Vec3 center,
                                        double radius, float damage, String label) {
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
        SpaceEffects.burst(level, center, ParticleTypes.FLAME, 70, 0.95, 0.1);
        SpaceEffects.burst(level, center, ParticleTypes.CLOUD, 55, 0.9, 0.08);
        SpaceEffects.burst(level, center, ParticleTypes.SOUL_FIRE_FLAME, 30, 0.72, 0.08);
        for (int i = 0; i < 4; i++) {
            SpaceEffects.ring(level, center, radius * (0.35 + i * 0.19), 36,
                    i % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.ELECTRIC_SPARK,
                    0.08 + i * 0.12, i * 0.4);
        }
        level.playSound(null, BlockPos.containing(center), ModSounds.MISSILE_IMPACT, SoundSource.PLAYERS, 2.1F, 0.82F);
        damageRadius(level, player, center, radius, damage, 1.35);
        player.sendOverlayMessage(net.minecraft.network.chat.Component.literal("§6" + label + " §8// §fDETONATED"));
    }

    private static void empPulse(ServerLevel level, ServerPlayer player, Vec3 center) {
        SpaceEffects.burst(level, center, ParticleTypes.ELECTRIC_SPARK, 140, 1.7, 0.2);
        SpaceEffects.ring(level, center, 3.0, 48, ParticleTypes.ELECTRIC_SPARK, 0.05, 0.0);
        SpaceEffects.ring(level, center, 5.2, 56, ParticleTypes.END_ROD, 0.12, 0.3);
        SpaceEffects.ringPlane(level, center, 4.0, 36, ParticleTypes.SOUL_FIRE_FLAME, 0, 0.0, 1);
        SpaceEffects.ringPlane(level, center, 4.0, 36, ParticleTypes.SOUL_FIRE_FLAME, 0, 0.0, 2);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
        level.playSound(null, BlockPos.containing(center), ModSounds.EMP_BLAST, SoundSource.PLAYERS, 1.8F, 0.72F);
        damageRadius(level, player, center, 8.5, (float)(10.0F * OrbitalConfig.specialDamageMultiplier), 1.0);
        player.sendOverlayMessage(net.minecraft.network.chat.Component.literal("§bEMP PULSE §8// §fSYSTEM DISRUPTION"));
    }

    private static void damageRadius(ServerLevel level, ServerPlayer player, Vec3 center,
                                     double radius, float damage, double knockback) {
        AABB bounds = AABB.ofSize(center, radius * 2.0, radius * 2.0, radius * 2.0);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, bounds, LivingEntity::isAlive)) {
            if (entity == player || (entity instanceof ServerPlayer target && !player.canHarmPlayer(target))) continue;
            double distance = entity.position().distanceTo(center);
            if (distance > radius) continue;
            float scale = (float) Math.max(0.15, 1.0 - distance / radius * 0.75);
            entity.hurtServer(level, level.damageSources().playerAttack(player), damage * scale);
            Vec3 away = entity.position().subtract(center).normalize().scale(knockback * scale);
            entity.push(away.x, 0.45 * scale, away.z);
        }
    }

    private static void beam(ServerLevel level, Vec3 start, Vec3 end,
                             net.minecraft.core.particles.ParticleOptions particle, int segments) {
        SpaceEffects.beam(level, start, end, particle, segments, 0.012);
    }
}
