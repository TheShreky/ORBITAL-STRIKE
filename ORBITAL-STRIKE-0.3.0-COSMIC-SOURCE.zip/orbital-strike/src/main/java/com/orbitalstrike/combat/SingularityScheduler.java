package com.orbitalstrike.combat;

import com.orbitalstrike.config.OrbitalConfig;
import com.orbitalstrike.effects.SpaceEffects;
import com.orbitalstrike.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** A server-authoritative black hole with a rotating accretion disk and animated collapse. */
public final class SingularityScheduler {
    private static final List<Singularity> ACTIVE = new ArrayList<>();
    private SingularityScheduler() {}

    public static void create(ServerLevel level, ServerPlayer owner, Vec3 center) {
        ACTIVE.add(new Singularity(level.dimension(), center, owner.getUUID(), 100));
        owner.sendOverlayMessage(Component.literal("§5SINGULARITY §8// §fEVENT HORIZON DEPLOYED"));
        level.playSound(null, BlockPos.containing(center), ModSounds.SINGULARITY,
                SoundSource.PLAYERS, 2.2F, 0.68F);
        SpaceEffects.crosshair(level, center, 3.2, ParticleTypes.REVERSE_PORTAL, 0.0);
    }

    public static void tick(MinecraftServer server) {
        Iterator<Singularity> iterator = ACTIVE.iterator();
        while (iterator.hasNext()) {
            Singularity singularity = iterator.next();
            ServerLevel level = server.getLevel(singularity.dimension);
            if (level == null) { iterator.remove(); continue; }

            singularity.ticks--;
            Vec3 center = singularity.center;
            double progress = 1.0 - singularity.ticks / 100.0;
            double radius = 9.5 - progress * 2.3;
            double phase = singularity.ticks * -0.19;

            if (singularity.ticks % 4 == 0) {
                // Rotating accretion disk: three differently sized orbital planes.
                SpaceEffects.ring(level, center, radius, 44, ParticleTypes.PORTAL, 0.05, phase);
                SpaceEffects.ring(level, center, radius * 0.72, 36, ParticleTypes.REVERSE_PORTAL, 0.42, -phase * 1.4);
                SpaceEffects.ringPlane(level, center, radius * 0.62, 30,
                        ParticleTypes.END_ROD, 0, phase * 0.7, 1);
                SpaceEffects.ringPlane(level, center, radius * 0.62, 30,
                        ParticleTypes.SOUL_FIRE_FLAME, 0, -phase * 0.7, 2);

                // Twisted streams feed the event horizon from above and below.
                SpaceEffects.helix(level, center, 2.0, 8.0, 3, 28,
                        ParticleTypes.REVERSE_PORTAL, phase);
                SpaceEffects.helix(level, center, 1.45, 6.2, 2, 22,
                        ParticleTypes.SOUL_FIRE_FLAME, -phase * 1.2);
                SpaceEffects.burst(level, center, ParticleTypes.SMOKE, 5, 0.32, 0.015);
                SpaceEffects.burst(level, center, ParticleTypes.WITCH, 3, 0.2, 0.02);

                // Small orbiting sparks give the disk a satellite-like motion.
                for (int i = 0; i < 4; i++) {
                    double angle = phase * (i % 2 == 0 ? 1.0 : -1.0) + i * Math.PI / 2.0;
                    double orbit = radius * (0.82 + (i % 2) * 0.12);
                    Vec3 node = center.add(Math.cos(angle) * orbit,
                            Math.sin(angle * 1.8) * 0.7,
                            Math.sin(angle) * orbit);
                    level.sendParticles(i % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.ELECTRIC_SPARK,
                            node.x, node.y, node.z, 2, 0.025, 0.025, 0.025, 0.015);
                }

                AABB bounds = AABB.ofSize(center, radius * 2.0, radius * 2.0, radius * 2.0);
                ServerPlayer owner = server.getPlayerList().getPlayer(singularity.owner);
                for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, bounds, LivingEntity::isAlive)) {
                    if (owner != null && entity.getUUID().equals(owner.getUUID())) continue;
                    if (owner != null && entity instanceof ServerPlayer target && !owner.canHarmPlayer(target)) continue;
                    Vec3 pull = center.subtract(entity.position());
                    double distance = Math.max(1.2, pull.length());
                    double strength = Math.min(0.42, 3.2 / distance);
                    Vec3 impulse = pull.normalize().scale(strength);
                    entity.push(impulse.x, impulse.y + 0.025, impulse.z);
                    if (singularity.ticks % 20 == 0) {
                        entity.hurtServer(level, owner == null ? level.damageSources().generic() : level.damageSources().playerAttack(owner),
                                (float) (2.0F * OrbitalConfig.specialDamageMultiplier));
                    }
                }
            }

            if (singularity.ticks <= 0) {
                // The disk snaps inward, then erupts as a contained stellar shockwave.
                SpaceEffects.beam(level, center.add(0, 20, 0), center.add(0, -4, 0),
                        ParticleTypes.END_ROD, 28, 0.02);
                level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
                SpaceEffects.burst(level, center, ParticleTypes.REVERSE_PORTAL, 120, 1.8, 0.15);
                SpaceEffects.burst(level, center, ParticleTypes.SOUL_FIRE_FLAME, 90, 1.5, 0.13);
                SpaceEffects.burst(level, center, ParticleTypes.ELECTRIC_SPARK, 100, 1.7, 0.18);
                SpaceEffects.burst(level, center, ParticleTypes.CLOUD, 65, 1.2, 0.1);
                for (int i = 0; i < 5; i++) {
                    SpaceEffects.ring(level, center, 2.0 + i * 1.65, 40,
                            i % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.SOUL_FIRE_FLAME,
                            0.1 + i * 0.08, i * 0.4);
                }
                level.playSound(null, BlockPos.containing(center), ModSounds.ORBITAL_IMPACT,
                        SoundSource.BLOCKS, 3.0F, 0.55F);
                ServerPlayer owner = server.getPlayerList().getPlayer(singularity.owner);
                AABB bounds = AABB.ofSize(center, 9.0, 9.0, 9.0);
                for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, bounds, LivingEntity::isAlive)) {
                    if (owner != null && entity.getUUID().equals(owner.getUUID())) continue;
                    if (owner != null && entity instanceof ServerPlayer target && !owner.canHarmPlayer(target)) continue;
                    if (entity.position().distanceTo(center) <= 4.5) {
                        entity.hurtServer(level, owner == null ? level.damageSources().generic() : level.damageSources().playerAttack(owner),
                                (float) (18.0F * OrbitalConfig.specialDamageMultiplier));
                    }
                }
                if (owner != null) owner.sendOverlayMessage(Component.literal("§5SINGULARITY §8// §fSTELLAR COLLAPSE COMPLETE"));
                iterator.remove();
            }
        }
    }

    private static final class Singularity {
        private final ResourceKey<Level> dimension;
        private final Vec3 center;
        private final UUID owner;
        private int ticks;
        private Singularity(ResourceKey<Level> dimension, Vec3 center, UUID owner, int ticks) {
            this.dimension = dimension;
            this.center = center;
            this.owner = owner;
            this.ticks = ticks;
        }
    }
}
