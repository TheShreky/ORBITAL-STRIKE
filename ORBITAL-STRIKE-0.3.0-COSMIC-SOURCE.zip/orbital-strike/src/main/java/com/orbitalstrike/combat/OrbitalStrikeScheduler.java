package com.orbitalstrike.combat;

import com.orbitalstrike.config.OrbitalConfig;
import com.orbitalstrike.effects.SpaceEffects;
import com.orbitalstrike.sound.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** Server-only strike queue. Every cinematic is rendered from world particles; no client assets are required. */
public final class OrbitalStrikeScheduler {
    private static final List<PendingStrike> PENDING = new ArrayList<>();

    private OrbitalStrikeScheduler() {}

    public static void schedule(ServerLevel level, ServerPlayer owner, Vec3 target) {
        schedule(level, owner, target, OrbitalConfig.strikeDelayTicks,
                OrbitalConfig.strikeRadius, OrbitalConfig.strikeDamage, OrbitalConfig.terrainDamage,
                "ORBITAL STRIKE");
    }

    public static void schedule(ServerLevel level, ServerPlayer owner, Vec3 target,
                                int delay, double radius, float damage, boolean terrainDamage, String label) {
        int safeDelay = Math.max(1, delay);
        PENDING.add(new PendingStrike(level.dimension(), target, owner.getUUID(), safeDelay,
                radius, damage, terrainDamage, label));
        owner.sendOverlayMessage(Component.literal("§b" + label + " §8// §fSATELLITE LOCKED §8// §eIMPACT IN "
                + String.format("%.1f", safeDelay / 20.0) + "s"));
        renderTargetLock(level, target, safeDelay);
        level.playSound(null, BlockPos.containing(target), ModSounds.TARGET_LOCK,
                SoundSource.PLAYERS, 1.7F, 0.78F);
    }

    public static void tick(MinecraftServer server) {
        Iterator<PendingStrike> iterator = PENDING.iterator();
        while (iterator.hasNext()) {
            PendingStrike strike = iterator.next();
            ServerLevel level = server.getLevel(strike.dimension);
            if (level == null) {
                iterator.remove();
                continue;
            }

            strike.ticksRemaining--;
            if (strike.ticksRemaining > 0) {
                if (strike.ticksRemaining % 4 == 0) {
                    renderTargetLock(level, strike.position, strike.ticksRemaining);
                }
                if (strike.ticksRemaining == 40 || strike.ticksRemaining == 20) {
                    ServerPlayer owner = server.getPlayerList().getPlayer(strike.owner);
                    if (owner != null) {
                        owner.sendOverlayMessage(Component.literal(strike.ticksRemaining == 40
                                ? "§e" + strike.label + " §8// §fSATELLITE CHARGE 50%"
                                : "§c" + strike.label + " §8// §fIMPACT IMMINENT"));
                    }
                }
                continue;
            }

            detonate(level, strike, server.getPlayerList().getPlayer(strike.owner));
            iterator.remove();
        }
    }

    /** Animated targeting reticle, three orbital rings, moving satellites and a descending beam. */
    private static void renderTargetLock(ServerLevel level, Vec3 center, int ticksRemaining) {
        double phase = (100 - ticksRemaining) * 0.16;
        double charge = 1.0 - Math.min(1.0, ticksRemaining / 100.0);
        double radius = 2.45 + Math.sin(phase * 1.7) * 0.18 + charge * 0.45;

        SpaceEffects.ring(level, center, radius, 32, ParticleTypes.END_ROD, 0.08, phase);
        SpaceEffects.ring(level, center, radius * 0.68, 24, ParticleTypes.ENCHANT, 0.16, -phase * 1.35);
        SpaceEffects.ringPlane(level, center, radius * 0.82, 22,
                ParticleTypes.PORTAL, 0, phase * 0.8, 1);
        SpaceEffects.ringPlane(level, center, radius * 0.82, 22,
                ParticleTypes.REVERSE_PORTAL, 0, -phase * 0.8, 2);

        // Three tiny satellite markers orbit the lock point in opposing directions.
        for (int satellite = 0; satellite < 3; satellite++) {
            double angle = phase * (satellite == 1 ? -1.15 : 1.0) + satellite * Math.PI * 2.0 / 3.0;
            double orbit = radius + 1.25;
            Vec3 node = center.add(Math.cos(angle) * orbit,
                    1.0 + Math.sin(angle * 1.7) * 0.45,
                    Math.sin(angle) * orbit);
            SpaceEffects.burst(level, node, satellite == 1 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.END_ROD,
                    2, 0.015, 0.005);
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, node.x, node.y, node.z,
                    2, 0.04, 0.04, 0.04, 0.02);
        }

        // The orbital emitter periodically paints a visible column onto the target.
        if (ticksRemaining % 16 == 0 || ticksRemaining <= 12) {
            Vec3 beamTop = center.add(0, 18.0 + charge * 9.0, 0);
            SpaceEffects.beam(level, beamTop, center.add(0, 0.45, 0),
                    ParticleTypes.END_ROD, 18, 0.008);
            SpaceEffects.helix(level, center.add(0, 3.2, 0), 0.48, 5.4,
                    3, 22, ParticleTypes.ELECTRIC_SPARK, phase);
        }

        if (ticksRemaining % 10 == 0) {
            SpaceEffects.burst(level, center.add(0, 0.25, 0), ParticleTypes.SOUL_FIRE_FLAME,
                    8 + (int) (charge * 12), 0.42, 0.025 + charge * 0.02);
        }
    }

    /** Multi-stage-looking impact built from a vertical orbital lance and expanding shockwave rings. */
    private static void detonate(ServerLevel level, PendingStrike strike, ServerPlayer owner) {
        Vec3 center = strike.position;
        double radius = strike.radius;

        SpaceEffects.beam(level, center.add(0, 34, 0), center.add(0, -2, 0),
                ParticleTypes.END_ROD, 36, 0.025);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0, 0, 0, 0);
        SpaceEffects.burst(level, center, ParticleTypes.CLOUD, 110, 2.2, 0.16);
        SpaceEffects.burst(level, center, ParticleTypes.FLAME, 95, 1.8, 0.12);
        SpaceEffects.burst(level, center, ParticleTypes.SOUL_FIRE_FLAME, 70, 1.5, 0.13);
        SpaceEffects.burst(level, center, ParticleTypes.ELECTRIC_SPARK, 135, 2.0, 0.2);
        SpaceEffects.burst(level, center, ParticleTypes.TOTEM_OF_UNDYING, 42, 1.25, 0.17);

        for (int ring = 0; ring < 6; ring++) {
            double ringRadius = Math.max(1.0, radius * (0.22 + ring * 0.145));
            double y = 0.12 + ring * 0.11;
            SpaceEffects.ring(level, center, ringRadius, 44,
                    ring % 2 == 0 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.END_ROD,
                    y, ring * 0.35);
        }
        SpaceEffects.ringPlane(level, center.add(0, 0.4, 0), radius * 0.56, 34,
                ParticleTypes.ELECTRIC_SPARK, 0, 0.2, 1);
        SpaceEffects.ringPlane(level, center.add(0, 0.4, 0), radius * 0.56, 34,
                ParticleTypes.ELECTRIC_SPARK, 0, -0.2, 2);

        level.playSound(null, BlockPos.containing(center), ModSounds.ORBITAL_IMPACT,
                SoundSource.BLOCKS, 5.0F, strike.radius > 12.0 ? 0.52F : 0.72F);

        AABB area = AABB.ofSize(center, radius * 2.0, radius * 2.0, radius * 2.0);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area, LivingEntity::isAlive)) {
            if (owner != null && entity.getUUID().equals(owner.getUUID())) continue;
            if (owner != null && entity instanceof ServerPlayer targetPlayer && !owner.canHarmPlayer(targetPlayer)) continue;
            double distance = entity.position().distanceTo(center);
            if (distance > radius) continue;
            float falloff = (float) Math.max(0.12, 1.0 - (distance / radius) * 0.78);
            entity.hurtServer(level, owner == null ? level.damageSources().generic() : level.damageSources().playerAttack(owner), strike.damage * falloff);
            Vec3 away = entity.position().subtract(center).normalize().scale(2.2 * falloff);
            entity.push(away.x, 0.9 * falloff, away.z);
        }

        if (strike.terrainDamage && (owner == null || owner.getAbilities().mayBuild)) {
            destroyImpactTerrain(level, center, radius, owner);
        }
        if (owner != null) {
            owner.sendOverlayMessage(Component.literal("§6" + strike.label + " §8// §fIMPACT CONFIRMED"));
        }
    }

    private static void destroyImpactTerrain(ServerLevel level, Vec3 center, double radius, ServerPlayer owner) {
        int extent = (int) Math.ceil(Math.min(radius * 0.72, 10.0));
        BlockPos origin = BlockPos.containing(center);
        int checks = 0;
        for (int x = -extent; x <= extent; x++) {
            for (int y = -extent; y <= extent; y++) {
                for (int z = -extent; z <= extent; z++) {
                    if (++checks > 7000) return;
                    double distance = Math.sqrt(x * x + y * y * 0.7 + z * z);
                    if (distance > radius * 0.72) continue;
                    BlockPos pos = origin.offset(x, y, z);
                    var state = level.getBlockState(pos);
                    if (state.isAir()) continue;
                    float hardness = state.getDestroySpeed(level, pos);
                    if (hardness < 0.0F || hardness > 18.0F) continue;
                    float chance = (float) (0.82 - distance / (radius * 1.65));
                    if (level.getRandom().nextFloat() < chance) level.destroyBlock(pos, true, owner);
                }
            }
        }
    }

    private static final class PendingStrike {
        private final ResourceKey<Level> dimension;
        private final Vec3 position;
        private final UUID owner;
        private final double radius;
        private final float damage;
        private final boolean terrainDamage;
        private final String label;
        private int ticksRemaining;

        private PendingStrike(ResourceKey<Level> dimension, Vec3 position, UUID owner, int delay,
                              double radius, float damage, boolean terrainDamage, String label) {
            this.dimension = dimension;
            this.position = position;
            this.owner = owner;
            this.ticksRemaining = delay;
            this.radius = radius;
            this.damage = damage;
            this.terrainDamage = terrainDamage;
            this.label = label;
        }
    }
}
