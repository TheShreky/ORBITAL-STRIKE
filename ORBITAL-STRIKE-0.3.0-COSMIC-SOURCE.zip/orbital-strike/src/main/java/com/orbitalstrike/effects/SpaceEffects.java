package com.orbitalstrike.effects;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/** Lightweight server-driven particle geometry used by the weapon VFX. */
public final class SpaceEffects {
    private SpaceEffects() {}

    public static void ring(ServerLevel level, Vec3 center, double radius, int points,
                            ParticleOptions particle, double yOffset, double phase) {
        ringPlane(level, center, radius, points, particle, yOffset, phase, 0);
    }

    /** plane 0 = horizontal, 1 = vertical X/Y, 2 = vertical Z/Y. */
    public static void ringPlane(ServerLevel level, Vec3 center, double radius, int points,
                                 ParticleOptions particle, double offset, double phase, int plane) {
        int safePoints = Math.max(8, points);
        for (int i = 0; i < safePoints; i++) {
            double angle = phase + Math.PI * 2.0 * i / safePoints;
            double a = Math.cos(angle) * radius;
            double b = Math.sin(angle) * radius;
            double x = center.x;
            double y = center.y;
            double z = center.z;
            if (plane == 1) {
                x += a;
                y += b;
                z += offset;
            } else if (plane == 2) {
                x += offset;
                y += b;
                z += a;
            } else {
                x += a;
                y += offset;
                z += b;
            }
            level.sendParticles(particle, x, y, z, 1, 0, 0, 0, 0);
        }
    }

    public static void helix(ServerLevel level, Vec3 center, double radius, double height,
                             int turns, int points, ParticleOptions particle, double phase) {
        int safePoints = Math.max(12, points);
        for (int i = 0; i < safePoints; i++) {
            double progress = i / (double) (safePoints - 1);
            double angle = phase + progress * Math.PI * 2.0 * turns;
            double r = radius * (0.72 + 0.28 * Math.sin(progress * Math.PI));
            double x = center.x + Math.cos(angle) * r;
            double y = center.y - height * 0.5 + progress * height;
            double z = center.z + Math.sin(angle) * r;
            level.sendParticles(particle, x, y, z, 1, 0, 0, 0, 0);
        }
    }

    public static void beam(ServerLevel level, Vec3 start, Vec3 end,
                            ParticleOptions particle, int segments, double spread) {
        int safeSegments = Math.max(2, segments);
        for (int i = 0; i <= safeSegments; i++) {
            Vec3 point = start.lerp(end, i / (double) safeSegments);
            level.sendParticles(particle, point.x, point.y, point.z,
                    1, spread, spread, spread, 0);
        }
    }

    public static void burst(ServerLevel level, Vec3 center, ParticleOptions particle,
                             int count, double spread, double speed) {
        level.sendParticles(particle, center.x, center.y, center.z,
                count, spread, spread, spread, speed);
    }

    public static void crosshair(ServerLevel level, Vec3 center, double radius,
                                 ParticleOptions particle, double phase) {
        ring(level, center, radius, 40, particle, 0.06, phase);
        ringPlane(level, center.add(0, 0.02, 0), radius * 0.72, 28,
                particle, 0, phase * -0.7, 1);
        ringPlane(level, center.add(0, 0.02, 0), radius * 0.72, 28,
                particle, 0, phase * 0.7, 2);
    }
}
