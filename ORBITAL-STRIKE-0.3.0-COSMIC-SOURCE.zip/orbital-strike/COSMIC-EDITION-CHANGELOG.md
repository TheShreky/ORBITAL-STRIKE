# ORBITAL STRIKE — Cosmic Edition 0.3.0

## Visual systems

- Added an 8-frame animated energy treatment to 21 weapon/core textures. The pulse moves across the existing pixel-art assets rather than replacing their silhouettes.
- Added a shared particle-geometry utility for server-side rings, orbital planes, helices, beams, bursts and 3D reticles.
- Orbital Designator now displays a multi-plane target reticle, three moving satellite markers, periodic descending beam passes, a spiral charge column and an expanding six-ring impact wave.
- Nuclear orbital bombardment and drone missile telegraphs use the same satellite-lock cinematic at their own delay and scale.
- Black Hole Launcher now runs a 100-tick event-horizon effect with a rotating multi-plane accretion disk, twin feeding helices, orbiting sparks, entity attraction and a stellar-collapse wave.
- Plasma Rifle, Quantum Sniper, Orbital Laser, Railgun and Particle Accelerator use layered tracers and impact reticles.
- Energy Sword uses a visible curved particle slash; Gravity Manipulator uses a short-lived multi-plane gravity pulse; EMP uses crossing electric wavefronts.
- Effects use vanilla particles and server tick events. No extra rendering library or client-only renderer is introduced.

## Compatibility and safety checks

- Updated item cooldown calls to use the held ItemStack API.
- Updated fire duration and random-source calls for the 26.3 code line.
- Replaced particle types whose 26.3 generic signatures are not accepted by the simple sendParticles overload.
- Kept shaped-recipe ingredient declarations as `{ "item": "namespace:item" }` objects. The previous workflow's experimental string conversion is deliberately not used.
- Added `validate_project.py` to parse all JSON resources, validate recipe ingredient/result structures, check model texture references and verify animated texture frame dimensions before compiling.
- Disabled Gradle configuration cache for this build because the existing resource expansion task uses a closure that is incompatible with the cache configuration in this project.

## Verification status

Resource validation and Java syntax parsing passed in the preparation environment. A full Gradle compile and in-game Minecraft 26.3 test still need to run in GitHub Actions / the user's Fabric profile. Do not treat this source archive as a compiled JAR.
