# Development phase status

Release: **Cosmic Edition 0.3.0** — enhanced source/assets package. Resource validation has passed; Gradle compilation and an in-game Minecraft 26.3 test are still pending.

| Phase | Status | Delivered |
|---|---|---|
| 1 — Architecture and environment | Source updated | Fabric 26.3 project, Java 25 configuration, server config, architecture notes |
| 2 — Weapon systems and models | Expanded functional source implementation | Full 12-weapon roster plus Orbital Designator, 13 weapon/tool entries, individual low-poly item models and textures |
| 3 — Animations and VFX | Cosmic visual upgrade implemented in source | 21 animated 8-frame energy/weapon textures; multi-plane target reticles; orbiting satellite markers; descending orbital beam; triple-trail weapon beams; curved energy-sword slash; EMP wavefronts; expanding shockwaves; rotating black-hole accretion disk and twin particle helices |
| 4 — Orbital Strike | Functional source implementation, build pending | Delayed standard strike, operator-gated nuclear strike, delayed drone-missile strike, configurable damage and terrain settings, animated target lock and impact sequence |
| 5 — Technology, machines, drones, enemies | Partial/deferred | Crafting components and weapon progression exist; custom flying drone entity, turrets, generators, robot enemies and bosses are not implemented |
| 6 — Custom UI/HUD | Partial | Weapon/action feedback via action-bar overlays and status messages; full-screen holographic menus and animated radar HUD are not implemented |
| 7 — Multiplayer and optimization | Server-authoritative source design, untested | Server-side ray targeting, damage, cooldowns, scheduled impacts, singularity processing, PvP checks and throttled particle loops; dedicated-server test deferred |
| 8 — Testing and packaging | Resource validation passed | JSON, recipe structures, model texture references, animated texture dimensions and declared OGG resources checked. Full Gradle compilation, client launch, dedicated-server launch and final JAR still require GitHub Actions / Java 25 environment. |

## Explicitly not shipped as working features

No custom animated entity rigs, autonomous flying drone entity, hostile robot/soldier AI, mechanical boss, placeable turret, shield projector block, power generator block, holographic GUI screen, first-person reload/inspection animation controller, volumetric lighting or machine AI/Redstone EMP shutdown is included. The current drone missile uses a delayed, server-scheduled strike effect instead of a rendered autonomous drone. The EMP is an area pulse, not an AI/Redstone disabling mechanic.

## Build/test boundary

`validate_project.py` checks JSON syntax, shaped-recipe ingredient/result structures, item model texture references, animated PNG frame layout, and sound resource references/OGG headers. It does not replace Gradle compilation or Minecraft runtime tests. The preparation container has Java 21 and no Gradle executable, so no compiled JAR is claimed.
