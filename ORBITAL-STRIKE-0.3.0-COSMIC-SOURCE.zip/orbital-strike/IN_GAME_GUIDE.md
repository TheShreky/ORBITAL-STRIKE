> **Cosmic Edition 0.3.0:** weapon accents animate, orbital locks use rotating 3D reticles and satellite sparks, laser/plasma shots have layered trails, impacts create expanding shockwaves, and the black hole forms a rotating accretion disk.

# ORBITAL STRIKE — In-Game Field Manual

## 1. Get the weapons

The items are in the creative inventory:

- **Combat tab:** all 13 weapons/tools.
- **Ingredients tab:** Neutron Alloy, Quantum Core, Plasma Cell, and Orbital Circuit.

You can also use the following commands with cheats enabled or as an operator. Run them in chat exactly as shown:

```mcfunction
/give @s orbital_strike:orbital_designator 1
/give @s orbital_strike:plasma_rifle 1
/give @s orbital_strike:quantum_sniper 1
/give @s orbital_strike:orbital_laser_cannon 1
/give @s orbital_strike:heavy_railgun 1
/give @s orbital_strike:energy_sword 1
/give @s orbital_strike:nuclear_bombardment 1
/give @s orbital_strike:gravity_manipulator 1
/give @s orbital_strike:rocket_launcher 1
/give @s orbital_strike:drone_missile_system 1
/give @s orbital_strike:black_hole_launcher 1
/give @s orbital_strike:emp_cannon 1
/give @s orbital_strike:particle_accelerator 1
```

To get the crafting components:

```mcfunction
/give @s orbital_strike:neutron_alloy 16
/give @s orbital_strike:quantum_core 4
/give @s orbital_strike:plasma_cell 8
/give @s orbital_strike:orbital_circuit 8
```

## 2. Controls

All weapon actions use the Minecraft **Use Item** control (right-click by default). Aim at a block or entity, then right-click. Weapons run their damage and effect logic on the server, so multiplayer clients cannot decide their own damage results.

| Weapon | How to use it | What happens |
|---|---|---|
| Orbital Designator | Aim at the ground/target and right-click | Locks the location, then calls in a standard orbital strike after 2.5 seconds by default, with rotating multi-plane target lock, satellite sparks and a descending beam |
| Tactical Plasma Rifle | Aim at a living target and right-click | Fast, short-cooldown hitscan shot with three-color plasma trails and a pulsing muzzle effect; solid blocks stop it; sets hit targets on fire briefly |
| Quantum Sniper | Aim carefully and right-click | High-damage, long-range precision shot; solid blocks stop it |
| Orbital Laser Cannon | Aim at a target point and right-click | Fires a triple-strand long-range energy beam with a rotating impact reticle and small blast radius |
| Heavy Railgun | Line up multiple enemies and right-click | Pierces up to five living targets in the same visible line |
| Experimental Energy Sword | Get within about five blocks, aim at an enemy, right-click | Delivers a curved particle slash arc, spark burst and knockback |
| Nuclear Orbital Bombardment | Aim at the impact location and right-click | Calls a much larger strike after five seconds; intended as an endgame/admin weapon |
| Gravity Manipulator | Aim at the centre of a group and right-click | Pulls nearby living entities toward the selected point |
| Advanced Rocket Launcher | Aim at a surface or target and right-click | Immediate explosive impact with damage falloff and knockback |
| Drone-Controlled Missile System | Aim at the target location and right-click | Schedules a guided strike after about 1.9 seconds; it does not currently spawn a visible drone entity |
| Black Hole Launcher | Aim at the centre of the area and right-click | Creates a 100-tick gravity field with a rotating accretion disk that pulls entities inward, damages them periodically, then collapses in a stellar shockwave |
| Electromagnetic Pulse Cannon | Aim at the centre of a group and right-click | Emits multi-plane electric wavefronts with area damage and knockback; it does not currently shut down redstone or machine AI |
| Experimental Particle Accelerator | Line up enemies and right-click | Fires a piercing beam that can hit up to eight aligned living targets |

## 3. Permission notes

The standard Orbital Designator and Nuclear Orbital Bombardment require the Minecraft **GAMEMASTERS** permission by default. In ordinary multiplayer admin terms, make the player an operator from the server console:

```text
/op YourMinecraftName
```

To allow everyone on the server to use the orbital weapons, stop the server and change this setting in `config/orbital-strike.properties`:

```properties
orbital.require_operator=false
```

Do not enable public use of nuclear strikes on a public server unless that is intentional. The normal designator's terrain damage is also configurable.

## 4. Crafting progression

Use a crafting table. The chain is designed as a compact tech progression:

1. **Neutron Alloy** — crafted from Netherite, gold, and amethyst.
2. **Quantum Core** — crafted from Neutron Alloy, Ender Eyes, and amethyst.
3. **Plasma Cell** — crafted from copper, redstone, glowstone, and quartz.
4. **Orbital Circuit** — crafted from iron, gold, and redstone.
5. Use those advanced components with Netherite, Nether Stars, spyglass/repeater-style parts, or rockets to craft the specialist weapons.

The exact shaped recipes are in `src/main/resources/data/orbital_strike/recipe/`. The in-game recipe book may need the materials discovered first; use the `/give` commands above for testing.

## 5. Server configuration

The mod creates the file `config/orbital-strike.properties` after its first server launch. Stop the server before editing it, then restart to reload settings.

Useful specialist settings:

```properties
special.damage_multiplier=1.0
special.cooldown_multiplier=1.0
nuclear.terrain_damage=false
```

- `special.damage_multiplier=2.0` doubles damage for the specialist weapons.
- `special.cooldown_multiplier=0.5` halves their cooldowns.
- `nuclear.terrain_damage=true` allows nuclear bombardment to break eligible blocks. Back up the world first.

## 6. Troubleshooting

**Weapons do nothing:** confirm the mod and Fabric API are installed on the server and client, check that the profile is Minecraft 26.3, and verify the item is off cooldown. The Orbital Designator and Nuclear Bombardment additionally require operator permission unless `orbital.require_operator=false`.

**Missing item textures:** make sure you installed the compiled 0.3.0-cosmic JAR from this source tree, not an older 0.1.0-alpha build. Press `F3 + T` to reload resource assets.

**Cannot craft a weapon:** confirm you are using the matching recipe from this mod's version and have the required components. For immediate testing use the `/give` commands.

**Multiplayer desync or server protection conflicts:** the strike queue, damage, targeting, cooldowns, and VFX are server-authoritative, but claims/protection mods can have their own block-breaking policies. Test terrain damage on a backup world first.
