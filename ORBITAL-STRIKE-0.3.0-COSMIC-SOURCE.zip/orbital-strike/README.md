# ORBITAL STRIKE

**Cosmic Edition 0.3.0 — Minecraft Java Edition 26.3 — Fabric**

ORBITAL STRIKE is a server-authoritative science-fiction combat expansion. Cosmic Edition upgrades the full weapon roster with animated item textures, orbital target-lock cinematics, satellite markers, descending energy lances, multi-ring shockwaves, triple-trail laser beams, plasma trails, quantum impact reticles, energy-blade slash arcs, EMP wavefronts, and a rotating black-hole accretion disk.

> Important: this is a substantially expanded alpha source release, not a finished AAA mod. This source package includes the full implementation, but it still needs a successful GitHub Actions build and an in-game test on the target Minecraft 26.3 + Fabric profile before it can be called verified. No compiled JAR is included.

## Included gameplay systems

| System | Implemented behaviour |
|---|---|
| Orbital Designator | Animated satellite target lock, rotating 3D reticle, descending energy lance, six expanding shockwave rings, area damage and knockback; configurable terrain damage |
| Tactical Plasma Rifle | Server-side hitscan with block occlusion, three-color plasma trails, muzzle pulse, impact ring, burn effect and cooldown |
| Quantum Sniper | Server-side long-range precision hitscan, paired energy tracer, animated impact reticle and high damage |
| Orbital Laser Cannon | Three-strand orbital beam, rotating impact reticle and small impact damage radius |
| Heavy Railgun | Piercing hitscan against up to five aligned living targets |
| Experimental Energy Sword | Curved energy slash arc, spark burst and knockback |
| Nuclear Orbital Bombardment | Five-second satellite strike, large damage radius, optional terrain destruction; operator permission enabled by default |
| Gravity Manipulator | Pulls nearby living entities toward the targeted point |
| Advanced Rocket Launcher | Immediate area impact, damage falloff, knockback, flame/cloud VFX |
| Drone-Controlled Missile System | Delayed missile strike with target telegraph and area damage |
| Black Hole Launcher | 100-tick server-side singularity with rotating three-plane accretion disk, twin particle spirals, entity attraction, periodic damage and stellar-collapse shockwave |
| Electromagnetic Pulse Cannon | Multi-plane electric wavefront, area damage and knockback; it does not currently disable machine AI or redstone |
| Experimental Particle Accelerator | Long-range beam that pierces up to eight aligned living targets |

All 12 requested weapon concepts are represented by active item behaviour. The Orbital Designator is an additional utility item, so there are 13 weapon/tool entries in the Combat creative tab.

## Requirements

- Minecraft Java Edition **26.3**
- Java Development Kit **25** for compiling the source
- Fabric Loader **0.20.1** or newer in the 26.3 line
- Fabric API **0.166.2+26.3** (or a newer 26.3-compatible Fabric API release)
- Gradle **9.8.2**
- Fabric Loom **1.19-SNAPSHOT** as pinned in `gradle.properties`

The version pins follow Fabric's 26.3 example project and developer version selector. Minecraft 26.3 uses Java 25 and the 26.3 Fabric toolchain. Do not replace these values with older 1.21-era examples.

## Build on Windows (no GitHub, no manual Gradle install)

1. Install a JDK 25 distribution from https://adoptium.net/temurin/releases/?version=25 and finish the installer.
2. Extract this ZIP to a normal writable folder.
3. Open the extracted `orbital-strike` folder.
4. Double-click `BUILD-ORBITAL-STRIKE.bat`. It downloads Gradle 9.8.2 into the project folder automatically and starts the build. No Command Prompt typing is required.
5. If the build succeeds, the script opens `build/libs/`; use the remapped mod JAR there. If it fails, no working JAR was produced.

For a development client, open the folder in IntelliJ IDEA, set the Gradle JVM to JDK 25, let Gradle sync, then run the `runClient` task.

### Optional automated build using GitHub Actions (not required)

The repository includes `.github/workflows/build.yml`. Push the extracted project to a GitHub repository, open **Actions → Build ORBITAL STRIKE → Run workflow**, and download the `ORBITAL-STRIKE-0.3.0-COSMIC` artifact after a green build. The workflow validates resource JSON and recipe ingredient structure before compiling. A green build confirms compilation, but an in-game test is still required.

## Install and play

1. Install Fabric Loader for Minecraft **26.3** in the Minecraft Launcher.
2. Launch the new Fabric profile once, then close Minecraft.
3. Put the built `orbital-strike-0.3.0-cosmic.jar` and the matching 26.3 Fabric API JAR into `.minecraft/mods`.
4. Start the Fabric 26.3 profile. For multiplayer, install the mod and Fabric API on the server and require joining clients to have the same mod version.
5. Read `IN_GAME_GUIDE.md` for controls, `/give` commands, recipes, permission defaults, and the configuration file.

## Cosmic visual upgrade

- Animated 8-frame energy textures with a moving scan pulse for the weapon accents and signature cores.
- Rotating orbital reticles, satellite sparks, beam columns and spiral energy paths.
- Triple-strand laser and plasma trails, curved energy-sword slash, EMP rings and expanding impact shockwaves.
- Black-hole event horizon with a rotating accretion disk, crossing orbital planes and twin feeding spirals.
- Effects are emitted from server-side world ticks and vanilla particles; no client-only renderer or extra rendering library is required. Particle work is throttled during the longer-running effects.

## Project structure

```text
src/main/java/com/orbitalstrike/
  OrbitalStrikeMod.java
  config/       OrbitalConfig.java
  content/      ModItems.java
  combat/       WeaponTargeting.java, OrbitalStrikeScheduler.java,
                SingularityScheduler.java
  item/         OrbitalDesignatorItem.java, PlasmaRifleItem.java,
                QuantumSniperItem.java, AdvancedWeaponItem.java
  sound/        ModSounds.java

src/main/resources/
  fabric.mod.json
  assets/orbital_strike/   item definitions, blockbench-style cube models,
                           textures, GUI icon art, OGG sounds, translations
  data/orbital_strike/     shaped crafting recipes

docs/                      architecture and phase status
generate_assets.py         original Alpha asset generator
generate_expansion_assets.py expanded model/texture/sound generator
IN_GAME_GUIDE.md           player-facing controls and help
```

## Configuration

On first launch, the mod creates `config/orbital-strike.properties`.

| Setting | Default | Meaning |
|---|---:|---|
| `orbital.delay_ticks` | 50 | Designator delay; 20 ticks = 1 second |
| `orbital.cooldown_ticks` | 240 | Designator cooldown |
| `orbital.radius` | 9.0 | Standard orbital strike radius |
| `orbital.damage` | 32 | Standard orbital strike damage at the centre |
| `orbital.terrain_damage` | true | Allow the standard designator to destroy eligible blocks |
| `orbital.require_operator` | true | Require the Minecraft GAMEMASTERS permission for the standard designator and nuclear strike |
| `plasma.range` | 52 | Plasma rifle range |
| `plasma.damage` | 8 | Plasma rifle damage |
| `plasma.cooldown_ticks` | 10 | Plasma rifle cooldown |
| `sniper.range` | 128 | Quantum sniper range |
| `sniper.damage` | 27 | Quantum sniper damage |
| `sniper.cooldown_ticks` | 52 | Quantum sniper cooldown |
| `special.damage_multiplier` | 1.0 | Damage multiplier for specialist weapons |
| `special.cooldown_multiplier` | 1.0 | Cooldown multiplier for specialist weapons; lower = faster firing |
| `nuclear.terrain_damage` | false | Allow nuclear bombardment to destroy eligible blocks |

Values are clamped at load. The standard orbital strike and nuclear attack can alter terrain only when their relevant setting is enabled and the owner has build permission. Back up worlds before enabling terrain damage. Claim/protection mods may have independent rules and require compatibility testing.

## Honest feature boundary

The current release has real item behaviours, server-owned combat, particle VFX, sound effects, custom item models, recipes, and configurable damage/cooldowns. It does **not** yet include custom animated entity rigs, actual flying drone entities, hostile robot/boss AI, placeable turret or generator blocks, a full-screen holographic HUD, animated first-person reload/inspection sequences, volumetric lighting, or a research GUI. The drone missile is currently represented by a delayed, server-scheduled strike rather than a visible autonomous drone entity. The EMP is currently an area shockwave rather than a persistent machine-disable mechanic.

## Build verification status

Resource validation is performed by `validate_project.py`. Java compilation, Fabric remapping, a client launch, and a dedicated-server launch still need to be run in a network-enabled Java 25 + Gradle 9.8.2 environment. This container only has Java 21, has no Gradle executable, and cannot resolve external hosts to fetch the required toolchain and dependencies; therefore the archive intentionally contains source and assets only, not a fake or empty JAR.
