@echo off
setlocal

echo ==================================================
echo ORBITAL STRIKE - Minecraft 26.3 build
echo ==================================================

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java 25 JDK is required but java.exe was not found in PATH.
  exit /b 1
)
java -version 2>&1 | findstr /C:"25" >nul
if errorlevel 1 (
  echo ERROR: Java 25 is required. Set JAVA_HOME and PATH to a JDK 25 installation.
  java -version
  exit /b 1
)

where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle 9.8.2 was not found in PATH.
  echo Install Gradle 9.8.2, then run this file again.
  exit /b 1
)

gradle --version 2>&1 | findstr /C:"Gradle 9.8.2" >nul
if errorlevel 1 (
  echo ERROR: This project is pinned to Gradle 9.8.2. Check your installed version.
  gradle --version
  exit /b 1
)

gradle build --no-configuration-cache
if errorlevel 1 (
  echo BUILD FAILED. Review the Gradle output above.
  exit /b 1
)

echo BUILD SUCCESS. Check build\libs\ for the mod JAR.
endlocal
